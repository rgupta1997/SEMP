import express, { Router } from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import {
  createDisciplineSchema, createFormatSchema, createInstitutionSchema,
  createPermissionSchema, createRoleSchema, createSportSchema, updateDisciplineSchema,
  updateFormatSchema, updateInstitutionSchema, updatePermissionSchema, updateRoleSchema,
  updateSportSchema, registerSchema,
  createVenueSchema, updateVenueSchema, createGroundSchema, updateGroundSchema,
  createSponsorSchema, updateSponsorSchema, createTournamentSchema, updateTournamentSchema,
  createTournamentSportSchema, updateTournamentSportSchema,
  createTournamentDisciplineSchema, updateTournamentDisciplineSchema,
} from '@semp/shared';
import type { Prisma } from '../infra/prisma.js';
import { env } from '../config/env.js';
import { makeCrudRouter } from './crud.js';
import { asyncHandler, errorHandler } from './middleware/error.js';
import { parseAuth, requireAuth } from './middleware/auth.js';
import { validateBody } from './middleware/validate.js';
import { makeAuthRouter } from '../modules/iam/auth.routes.js';
import { makeMeRouter } from '../modules/iam/me.routes.js';
import { makeEventsRouter } from '../modules/events/events.routes.js';
import { makeEnrollmentRouter } from '../modules/enrollment/enrollment.routes.js';
import { makeTeamsRouter } from '../modules/teams/teams.routes.js';
import { makeFixturesRouter } from '../modules/fixtures/fixtures.routes.js';

export function buildApp(prisma: Prisma) {
  const app = express();
  // Dev: allow any localhost origin (Vite may pick 5173/5174/...). Tighten for prod.
  app.use(cors({
    origin: (origin, cb) => {
      if (!origin || /^http:\/\/localhost:\d+$/.test(origin) || origin === env.WEB_ORIGIN) cb(null, true);
      else cb(new Error('Not allowed by CORS'));
    },
  }));
  app.use(express.json());
  app.use(parseAuth);

  app.get('/health', (_req, res) => res.json({ ok: true }));

  const api = Router();

  // Public auth routes
  api.use('/auth', makeAuthRouter(prisma));

  // Everything below requires authentication.
  api.use(requireAuth);

  // ----- "Me"-scoped read endpoints (resolved from the authenticated user) -----
  api.use('/', makeMeRouter(prisma));

  // ----- Users (bespoke create to hash password; rest is generic) -----
  const users = Router();
  users.post('/', validateBody(registerSchema), asyncHandler(async (req, res) => {
    const { name, email, password, phone } = req.body;
    const password_hash = await bcrypt.hash(password, 10);
    const u = await prisma.users.create({ data: { name, email, phone, password_hash } });
    const { password_hash: _, ...rest } = u;
    res.status(201).json(rest);
  }));
  users.get('/', asyncHandler(async (req, res) => {
    const accountType = req.query.account_type as string | undefined;
    const institutionId = req.query.institution_id as string | undefined;
    const rows = await prisma.users.findMany({
      where: {
        ...(accountType ? { account_type: accountType } : {}),
        ...(institutionId ? { institution_id: institutionId } : {}),
      },
      select: {
        id: true, name: true, email: true, phone: true, is_active: true,
        is_super_admin: true, account_type: true, institution_id: true, created_at: true,
      },
      orderBy: { created_at: 'desc' },
    });
    res.json(rows);
  }));
  api.use('/users', users);

  // ----- Phase 1: platform setup (generic CRUD) -----
  api.use('/permissions', makeCrudRouter(prisma.permissions, {
    name: 'Permission', createSchema: createPermissionSchema, updateSchema: updatePermissionSchema,
    orderBy: { code: 'asc' },
  }));
  api.use('/roles', makeCrudRouter(prisma.roles, {
    name: 'Role', createSchema: createRoleSchema, updateSchema: updateRoleSchema,
    orderBy: { name: 'asc' },
  }));
  api.use('/sports', makeCrudRouter(prisma.sports, {
    name: 'Sport', createSchema: createSportSchema, updateSchema: updateSportSchema,
    orderBy: { name: 'asc' },
  }));
  api.use('/disciplines', makeCrudRouter(prisma.disciplines, {
    name: 'Discipline', createSchema: createDisciplineSchema, updateSchema: updateDisciplineSchema,
    listFilters: ['sport_id'], orderBy: { display_order: 'asc' },
  }));
  api.use('/tournament-formats', makeCrudRouter(prisma.tournament_formats, {
    name: 'Tournament format', createSchema: createFormatSchema, updateSchema: updateFormatSchema,
    orderBy: { name: 'asc' },
  }));
  api.use('/institutions', makeCrudRouter(prisma.institutions, {
    name: 'Institution', createSchema: createInstitutionSchema, updateSchema: updateInstitutionSchema,
    orderBy: { name: 'asc' },
  }));

  // ----- Phase 2: event creation -----
  api.use('/events', makeEventsRouter(prisma));
  api.use('/venues', makeCrudRouter(prisma.venues, {
    name: 'Venue', createSchema: createVenueSchema, updateSchema: updateVenueSchema,
    listFilters: ['event_id'], orderBy: { created_at: 'asc' },
  }));
  api.use('/venue-grounds', makeCrudRouter(prisma.venue_grounds, {
    name: 'Ground', createSchema: createGroundSchema, updateSchema: updateGroundSchema,
    listFilters: ['venue_id'], orderBy: { display_order: 'asc' },
  }));
  api.use('/sponsors', makeCrudRouter(prisma.sponsors, {
    name: 'Sponsor', createSchema: createSponsorSchema, updateSchema: updateSponsorSchema,
    listFilters: ['event_id'], orderBy: { display_order: 'asc' },
  }));
  api.use('/tournaments', makeCrudRouter(prisma.tournaments, {
    name: 'Tournament', createSchema: createTournamentSchema, updateSchema: updateTournamentSchema,
    listFilters: ['event_id'], orderBy: { created_at: 'desc' },
  }));
  api.use('/tournament-sports', makeCrudRouter(prisma.tournament_sports, {
    name: 'Tournament sport', createSchema: createTournamentSportSchema, updateSchema: updateTournamentSportSchema,
    listFilters: ['tournament_id', 'sport_id'], orderBy: { display_order: 'asc' },
  }));
  api.use('/tournament-disciplines', makeCrudRouter(prisma.tournament_disciplines, {
    name: 'Tournament discipline', createSchema: createTournamentDisciplineSchema, updateSchema: updateTournamentDisciplineSchema,
    listFilters: ['tournament_sport_id', 'discipline_id'], orderBy: { display_order: 'asc' },
  }));

  // ----- Phase 3: enrollment & role assignment -----
  api.use('/', makeEnrollmentRouter(prisma));

  // ----- Phase 4: teams & rosters -----
  api.use('/', makeTeamsRouter(prisma));

  // ----- Phase 5: fixtures -----
  api.use('/', makeFixturesRouter(prisma));

  app.use('/api', api);
  app.use(errorHandler);
  return app;
}
