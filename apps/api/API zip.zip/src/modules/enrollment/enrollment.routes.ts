import { Router } from 'express';
import { assignRoleSchema, enrollInstitutionSchema, reviewEnrollmentSchema } from '@semp/shared';
import type { Prisma } from '../../infra/prisma.js';
import { asyncHandler } from '../../http/middleware/error.js';
import { validateBody } from '../../http/middleware/validate.js';
import { NotFoundError } from '../../shared/errors.js';

export function makeEnrollmentRouter(prisma: Prisma): Router {
  const router = Router();

  // Institution applies to an event (status: pending, stamps applied_by).
  router.post('/events/:eventId/enroll', validateBody(enrollInstitutionSchema), asyncHandler(async (req, res) => {
    const row = await prisma.event_institutions.create({
      data: {
        event_id: req.params.eventId,
        institution_id: req.body.institution_id,
        applied_by: req.user!.id,
        status: 'pending',
      },
    });
    res.status(201).json(row);
  }));

  // Enrollment queue for an event (optionally filtered by status).
  router.get('/events/:eventId/enrollments', asyncHandler(async (req, res) => {
    const status = req.query.status as string | undefined;
    const rows = await prisma.event_institutions.findMany({
      where: { event_id: req.params.eventId, ...(status ? { status } : {}) },
      include: { institutions: true },
      orderBy: { applied_at: 'asc' },
    });
    res.json(rows);
  }));

  // Approve / reject an enrollment (stamps reviewer + timestamp).
  router.patch('/event-institutions/:id', validateBody(reviewEnrollmentSchema), asyncHandler(async (req, res) => {
    const existing = await prisma.event_institutions.findUnique({ where: { id: req.params.id } });
    if (!existing) throw new NotFoundError('Enrollment');
    const row = await prisma.event_institutions.update({
      where: { id: req.params.id },
      data: {
        status: req.body.status,
        rejection_note: req.body.status === 'rejected' ? req.body.rejection_note ?? null : null,
        reviewed_by: req.user!.id,
        reviewed_at: new Date(),
      },
    });
    res.json(row);
  }));

  // Assign an event-scoped role to a user (e.g. Captain) via user_event_roles.
  router.post('/events/:eventId/roles', validateBody(assignRoleSchema), asyncHandler(async (req, res) => {
    const row = await prisma.user_event_roles.create({
      data: {
        event_id: req.params.eventId,
        user_id: req.body.user_id,
        role_id: req.body.role_id,
        assigned_by: req.user!.id,
      },
    });
    res.status(201).json(row);
  }));

  // List event-scoped role assignments.
  router.get('/events/:eventId/roles', asyncHandler(async (req, res) => {
    const rows = await prisma.user_event_roles.findMany({
      where: { event_id: req.params.eventId },
      include: { users_user_event_roles_user_idTousers: true, roles: true },
      orderBy: { assigned_at: 'desc' },
    });
    res.json(rows);
  }));

  return router;
}
