import { Router } from 'express';
import { createFixtureSchema, fixtureResultSchema, generateFixturesSchema, updateFixtureSchema } from '@semp/shared';
import type { Prisma } from '../../infra/prisma.js';
import { makeCrudRouter } from '../../http/crud.js';
import { asyncHandler } from '../../http/middleware/error.js';
import { validateBody } from '../../http/middleware/validate.js';
import { BusinessRuleError, NotFoundError } from '../../shared/errors.js';
import { generateFixtures, type TeamRef } from './domain/generators/index.js';

export function makeFixturesRouter(prisma: Prisma): Router {
  const router = Router();

  // List fixtures for a discipline draw.
  router.get('/tournament-disciplines/:id/fixtures', asyncHandler(async (req, res) => {
    const rows = await prisma.fixtures.findMany({
      where: { tournament_discipline_id: req.params.id },
      orderBy: [{ pool_number: 'asc' }, { bracket_position: 'asc' }, { created_at: 'asc' }],
    });
    res.json(rows);
  }));

  // Generate (regenerate) the draw using the format's algorithm.
  router.post('/tournament-disciplines/:id/fixtures/generate',
    validateBody(generateFixturesSchema),
    asyncHandler(async (req, res) => {
      const td = await prisma.tournament_disciplines.findUnique({
        where: { id: req.params.id },
        include: {
          tournament_formats: true,
          tournament_sports: { include: { tournament_formats: true } },
        },
      });
      if (!td) throw new NotFoundError('Tournament discipline');

      const formatName = td.tournament_formats?.name ?? td.tournament_sports.tournament_formats?.name;
      if (!formatName) throw new BusinessRuleError('No format configured for this draw');

      const params: Record<string, unknown> = {
        ...(td.tournament_sports.format_config as object),
        ...(td.format_config as object),
        ...(req.body.params as object),
      };

      // Teams: explicit seed order, else all teams registered to this draw.
      let teams: TeamRef[];
      if (req.body.team_ids?.length) {
        teams = req.body.team_ids.map((id: string) => ({ teamId: id }));
      } else {
        const registered = await prisma.teams.findMany({
          where: { tournament_discipline_id: td.id },
          orderBy: { created_at: 'asc' },
        });
        teams = registered.map((t) => ({ teamId: t.id }));
      }

      const generated = generateFixtures(formatName, teams, params);

      // Replace any existing fixtures for this draw.
      await prisma.fixtures.deleteMany({ where: { tournament_discipline_id: td.id } });
      await prisma.fixtures.createMany({
        data: generated.map((f) => ({
          tournament_discipline_id: td.id,
          home_team_id: f.homeTeamId,
          away_team_id: f.awayTeamId,
          round: f.round,
          pool_number: f.poolNumber,
          bracket_position: f.bracketPosition,
          status: f.status,
        })),
      });

      const rows = await prisma.fixtures.findMany({
        where: { tournament_discipline_id: td.id },
        orderBy: [{ pool_number: 'asc' }, { bracket_position: 'asc' }, { created_at: 'asc' }],
      });
      res.status(201).json(rows);
    }));

  // Record a result from the match console. Derives the winner from scores when
  // not given explicitly, and defaults the status to completed.
  router.patch('/fixtures/:id/result', validateBody(fixtureResultSchema), asyncHandler(async (req, res) => {
    const fixture = await prisma.fixtures.findUnique({ where: { id: req.params.id } });
    if (!fixture) throw new NotFoundError('Fixture');

    const home = req.body.home_score ?? null;
    const away = req.body.away_score ?? null;

    let winner = req.body.winner_team_id ?? null;
    if (winner === null && home !== null && away !== null) {
      if (home > away) winner = fixture.home_team_id;
      else if (away > home) winner = fixture.away_team_id;
      else winner = null; // draw
    }

    const updated = await prisma.fixtures.update({
      where: { id: req.params.id },
      data: {
        home_score: home,
        away_score: away,
        winner_team_id: winner,
        status: req.body.status ?? 'completed',
        notes: req.body.notes ?? fixture.notes,
      },
    });
    res.json(updated);
  }));

  // Plain CRUD for manual fixture edits / scheduling.
  router.use('/fixtures', makeCrudRouter(prisma.fixtures, {
    name: 'Fixture',
    createSchema: createFixtureSchema,
    updateSchema: updateFixtureSchema,
    listFilters: ['tournament_discipline_id'],
    orderBy: [{ pool_number: 'asc' }, { bracket_position: 'asc' }, { created_at: 'asc' }],
  }));

  return router;
}
