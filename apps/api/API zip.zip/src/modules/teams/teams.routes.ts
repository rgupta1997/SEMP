import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import bcrypt from 'bcryptjs';
import {
  addTeamMemberSchema, bulkAddTeamMembersSchema, bulkCreateTeamsSchema,
  createTeamSchema, joinTeamSchema, updateTeamSchema,
} from '@semp/shared';
import type { Prisma } from '../../infra/prisma.js';
import { asyncHandler } from '../../http/middleware/error.js';
import { validateBody } from '../../http/middleware/validate.js';
import { BusinessRuleError, NotFoundError } from '../../shared/errors.js';
import { resolveEntryRules } from '../tournaments/domain/entry-rules.js';
import { assertCanAddMember, assertCanLockRoster } from './domain/roster-policy.js';

// Default password for auto-provisioned players from a bulk import. They can be
// invited / reset later; precomputed once to keep the bulk loop cheap.
const DEFAULT_IMPORT_PASSWORD_HASH = bcrypt.hashSync('demo123', 10);

async function rulesForTeam(prisma: Prisma, tournamentDisciplineId: string | null) {
  if (!tournamentDisciplineId) return resolveEntryRules({}, null);
  const td = await prisma.tournament_disciplines.findUnique({
    where: { id: tournamentDisciplineId },
    include: { disciplines: true },
  });
  return resolveEntryRules(td ?? {}, td?.disciplines ?? null);
}

export function makeTeamsRouter(prisma: Prisma): Router {
  const router = Router();

  router.get('/teams', asyncHandler(async (req, res) => {
    const where: Record<string, unknown> = {};
    for (const k of ['event_id', 'tournament_discipline_id', 'institution_id', 'sport_id']) {
      if (req.query[k] !== undefined) where[k] = req.query[k];
    }
    const rows = await prisma.teams.findMany({
      where,
      include: {
        institutions: true,
        sports: true,
        events: { select: { id: true, name: true, slug: true, status: true } },
        tournament_disciplines: { include: { disciplines: true } },
        team_members: { include: { users: { select: { id: true, name: true, email: true } } } },
      },
      orderBy: { created_at: 'desc' },
    });
    res.json(rows);
  }));

  // Resolve an invite token (public-ish within the app) -> team summary.
  router.get('/teams/by-token/:token', asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({
      where: { invite_token: req.params.token },
      include: { institutions: true, sports: true },
    });
    if (!team) throw new NotFoundError('Team');
    res.json(team);
  }));

  router.get('/teams/:id', asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({
      where: { id: req.params.id },
      include: {
        team_members: { include: { users: true } },
        institutions: true, sports: true, events: { select: { id: true, name: true, slug: true, status: true } },
        tournament_disciplines: { include: { disciplines: true } },
      },
    });
    if (!team) throw new NotFoundError('Team');
    // Resolve the effective squad rules so the roster UI can show limits + validate.
    const entry_rules = resolveEntryRules(
      team.tournament_disciplines ?? {},
      team.tournament_disciplines?.disciplines ?? null,
    );
    res.json({ ...team, entry_rules });
  }));

  // Create a team — requires the institution's enrollment to be approved.
  // The creating user is automatically enrolled as the team captain so the team
  // shows up in their "my teams" immediately (and survives a refresh).
  router.post('/teams', validateBody(createTeamSchema), asyncHandler(async (req, res) => {
    const ei = await prisma.event_institutions.findUnique({ where: { id: req.body.event_institution_id } });
    if (!ei) throw new NotFoundError('Enrollment');
    if (ei.status !== 'approved') {
      throw new BusinessRuleError('Institution enrollment is not approved for this event');
    }
    const creatorId = req.user!.id;
    const team = await prisma.$transaction(async (tx) => {
      const created = await tx.teams.create({
        data: {
          event_id: req.body.event_id,
          sport_id: req.body.sport_id,
          institution_id: req.body.institution_id,
          event_institution_id: req.body.event_institution_id,
          tournament_discipline_id: req.body.tournament_discipline_id ?? null,
          name: req.body.name,
          status: 'forming',
          invite_token: randomBytes(16).toString('hex'),
        },
      });
      // Seed the roster with the creator as captain (idempotent-safe: one row).
      await tx.team_members.create({
        data: { team_id: created.id, user_id: creatorId, role: 'captain' },
      });
      return tx.teams.findUnique({
        where: { id: created.id },
        include: { team_members: { include: { users: true } }, institutions: true, sports: true },
      });
    });
    res.status(201).json(team);
  }));

  // Bulk-create teams (one per selected discipline), each with the creator as
  // captain. All-or-nothing so a partial failure never leaves orphan teams.
  router.post('/teams/bulk', validateBody(bulkCreateTeamsSchema), asyncHandler(async (req, res) => {
    const creatorId = req.user!.id;
    const created = await prisma.$transaction(async (tx) => {
      const out: any[] = [];
      for (const t of req.body.teams) {
        const ei = await tx.event_institutions.findUnique({ where: { id: t.event_institution_id } });
        if (!ei) throw new NotFoundError('Enrollment');
        if (ei.status !== 'approved') throw new BusinessRuleError(`Enrollment not approved for "${t.name}"`);
        const team = await tx.teams.create({
          data: {
            event_id: t.event_id,
            sport_id: t.sport_id,
            institution_id: t.institution_id,
            event_institution_id: t.event_institution_id,
            tournament_discipline_id: t.tournament_discipline_id ?? null,
            name: t.name,
            status: 'forming',
            invite_token: randomBytes(16).toString('hex'),
          },
        });
        await tx.team_members.create({ data: { team_id: team.id, user_id: creatorId, role: 'captain' } });
        out.push(team);
      }
      return out;
    });
    res.status(201).json({ created: created.length, teams: created });
  }));

  router.patch('/teams/:id', validateBody(updateTeamSchema), asyncHandler(async (req, res) => {
    const team = await prisma.teams.update({ where: { id: req.params.id }, data: req.body });
    res.json(team);
  }));

  router.delete('/teams/:id', asyncHandler(async (req, res) => {
    await prisma.teams.delete({ where: { id: req.params.id } });
    res.status(204).send();
  }));

  // Lock the roster (validates squad size against resolved entry rules).
  router.post('/teams/:id/lock', asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({ where: { id: req.params.id } });
    if (!team) throw new NotFoundError('Team');
    const count = await prisma.team_members.count({ where: { team_id: team.id, is_active: true } });
    const rules = await rulesForTeam(prisma, team.tournament_discipline_id);
    assertCanLockRoster(rules, count);
    const updated = await prisma.teams.update({ where: { id: team.id }, data: { status: 'roster_locked' } });
    res.json(updated);
  }));

  // ---- members ----
  router.get('/teams/:id/members', asyncHandler(async (req, res) => {
    const rows = await prisma.team_members.findMany({
      where: { team_id: req.params.id },
      include: { users: true },
      orderBy: { joined_at: 'asc' },
    });
    res.json(rows);
  }));

  async function addMember(prisma: Prisma, teamId: string, data: { user_id: string; role: string; jersey_number?: number }) {
    const team = await prisma.teams.findUnique({ where: { id: teamId } });
    if (!team) throw new NotFoundError('Team');
    if (team.status === 'roster_locked') throw new BusinessRuleError('Roster is locked');
    const count = await prisma.team_members.count({ where: { team_id: teamId, is_active: true } });
    const rules = await rulesForTeam(prisma, team.tournament_discipline_id);
    assertCanAddMember(rules, count);
    return prisma.team_members.create({
      data: { team_id: teamId, user_id: data.user_id, role: data.role, jersey_number: data.jersey_number ?? null },
    });
  }

  router.post('/teams/:id/members', validateBody(addTeamMemberSchema), asyncHandler(async (req, res) => {
    const member = await addMember(prisma, req.params.id, req.body);
    res.status(201).json(member);
  }));

  // Bulk roster import: accepts existing users and/or name+email rows. Emails are
  // resolved (matched or auto-created under the team's institution). Validates the
  // whole batch against squad_max up front, then inserts atomically.
  router.post('/teams/:id/members/bulk', validateBody(bulkAddTeamMembersSchema), asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({ where: { id: req.params.id } });
    if (!team) throw new NotFoundError('Team');
    if (team.status === 'roster_locked') throw new BusinessRuleError('Roster is locked');
    const rules = await rulesForTeam(prisma, team.tournament_discipline_id);

    const result = await prisma.$transaction(async (tx) => {
      let count = await tx.team_members.count({ where: { team_id: team.id, is_active: true } });
      const added: { name: string; email?: string }[] = [];
      const skipped: { label: string; reason: string }[] = [];

      for (const row of req.body.members as Array<{ user_id?: string; name?: string; email?: string; role: string; jersey_number?: number | null }>) {
        // Resolve the user: explicit id, else match/create by email.
        let userId = row.user_id ?? null;
        let label = row.name || row.email || 'member';
        if (!userId && row.email) {
          const existing = await tx.users.findUnique({ where: { email: row.email } });
          if (existing) {
            userId = existing.id;
            label = existing.name;
          } else {
            const u = await tx.users.create({
              data: {
                name: row.name?.trim() || row.email.split('@')[0],
                email: row.email,
                password_hash: DEFAULT_IMPORT_PASSWORD_HASH,
                account_type: 'participant',
                institution_id: team.institution_id,
              },
            });
            userId = u.id;
            label = u.name;
          }
        }
        if (!userId) { skipped.push({ label, reason: 'no user/email' }); continue; }

        const already = await tx.team_members.findFirst({ where: { team_id: team.id, user_id: userId } });
        if (already) { skipped.push({ label, reason: 'already on roster' }); continue; }

        if (count + 1 > rules.squad_max) {
          throw new BusinessRuleError(`Squad limit reached: a ${rules.entry_type} draw allows at most ${rules.squad_max} members`);
        }
        await tx.team_members.create({
          data: { team_id: team.id, user_id: userId, role: row.role, jersey_number: row.jersey_number ?? null },
        });
        count++;
        added.push({ name: label, email: row.email });
      }
      return { added: added.length, skipped, total: count };
    });

    res.status(201).json(result);
  }));

  // Join via invite token as the current authenticated user.
  router.post('/teams/by-token/:token/join', validateBody(joinTeamSchema), asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({ where: { invite_token: req.params.token } });
    if (!team) throw new NotFoundError('Team');
    const member = await addMember(prisma, team.id, { user_id: req.user!.id, role: req.body.role, jersey_number: req.body.jersey_number });
    res.status(201).json(member);
  }));

  router.delete('/teams/:id/members/:memberId', asyncHandler(async (req, res) => {
    const team = await prisma.teams.findUnique({ where: { id: req.params.id } });
    if (!team) throw new NotFoundError('Team');
    if (team.status === 'roster_locked') throw new BusinessRuleError('Roster is locked');
    await prisma.team_members.delete({ where: { id: req.params.memberId } });
    res.status(204).send();
  }));

  return router;
}
