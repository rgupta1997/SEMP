import { useState } from 'react';
import { api } from '../../../lib/api';
import { useApi, useApiMutation } from '../../../lib/hooks';
import { Button, Card, CardBody, EmptyState, Field, Input, Modal, StatusBadge, Textarea } from '../../../components/ui';

export function TournamentsTab({ eventId }: { eventId: string }) {
  const path = `/tournaments?event_id=${eventId}`;
  const { data: tournaments = [], isLoading } = useApi<any[]>(path);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  const create = useApiMutation(
    (body: any) => api('POST', '/tournaments', body),
    [path],
    () => { setOpen(false); setName(''); setDescription(''); },
  );

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-slate-500">A tournament groups the sports & disciplines that share a championship table.</p>
        <Button onClick={() => setOpen(true)}>+ Add tournament</Button>
      </div>

      {isLoading ? null : tournaments.length === 0 ? (
        <EmptyState icon="⊟" title="No tournaments" description="Add a tournament, then configure the sports and disciplines inside it."
          action={<Button onClick={() => setOpen(true)}>+ Add tournament</Button>} />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {tournaments.map((t) => (
            <Card key={t.id} className="p-4">
              <div className="flex items-start justify-between">
                <h3 className="font-semibold text-slate-900">{t.name}</h3>
                <StatusBadge status={t.status} />
              </div>
              {t.description && <p className="mt-1 text-sm text-slate-500">{t.description}</p>}
              <p className="mt-3 text-xs text-slate-400">Configure its sports in the “Sports &amp; disciplines” tab.</p>
            </Card>
          ))}
        </div>
      )}

      {open && (
        <Modal title="New tournament" onClose={() => setOpen(false)}>
          <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Main Championship" /></Field>
          <Field label="Description"><Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
          {error && <p className="mb-2 text-sm text-rose-600">{error}</p>}
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={!name || create.isPending}
              onClick={() => { setError(null); create.mutate({ event_id: eventId, name, description: description || undefined }, { onError: (e: any) => setError(e.message) }); }}>
              {create.isPending ? 'Saving…' : 'Create'}
            </Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
