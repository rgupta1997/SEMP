import { useState } from 'react';
import { api } from '../../../lib/api';
import { useApi, useApiMutation } from '../../../lib/hooks';
import { GROUND_TYPE } from '@semp/shared';
import { Badge, Button, Card, EmptyState, Field, Input, Modal, Select } from '../../../components/ui';

function GroundsPanel({ venueId }: { venueId: string }) {
  const path = `/venue-grounds?venue_id=${venueId}`;
  const { data: grounds = [] } = useApi<any[]>(path);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState('court');
  const add = useApiMutation((body: any) => api('POST', '/venue-grounds', body), [path], () => { setOpen(false); setName(''); });

  return (
    <div className="mt-3 border-t border-slate-100 pt-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Grounds / courts</span>
        <Button size="sm" variant="subtle" onClick={() => setOpen(true)}>+ Add ground</Button>
      </div>
      {grounds.length === 0 ? (
        <p className="text-sm text-slate-400">No grounds yet.</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {grounds.map((g) => <Badge key={g.id} tone="slate">{g.name} · {g.ground_type}</Badge>)}
        </div>
      )}
      {open && (
        <Modal title="Add ground / court" onClose={() => setOpen(false)}>
          <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Ground A" /></Field>
          <Field label="Type">
            <Select value={type} onChange={(e) => setType(e.target.value)}>{GROUND_TYPE.map((t) => <option key={t} value={t}>{t}</option>)}</Select>
          </Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={!name || add.isPending} onClick={() => add.mutate({ venue_id: venueId, name, ground_type: type })}>Add</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

export function VenuesTab({ eventId }: { eventId: string }) {
  const path = `/venues?event_id=${eventId}`;
  const { data: venues = [] } = useApi<any[]>(path);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const create = useApiMutation((body: any) => api('POST', '/venues', body), [path], () => { setOpen(false); setName(''); setCity(''); setAddress(''); });

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-slate-500">Venues hold the grounds, courts and pools where fixtures are played.</p>
        <Button onClick={() => setOpen(true)}>+ Add venue</Button>
      </div>

      {venues.length === 0 ? (
        <EmptyState icon="📍" title="No venues" description="Add a venue, then the grounds and courts within it."
          action={<Button onClick={() => setOpen(true)}>+ Add venue</Button>} />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {venues.map((v) => (
            <Card key={v.id} className="p-4">
              <h3 className="font-semibold text-slate-900">{v.name}</h3>
              <p className="text-sm text-slate-500">{[v.address, v.city].filter(Boolean).join(', ') || 'No address'}</p>
              <GroundsPanel venueId={v.id} />
            </Card>
          ))}
        </div>
      )}

      {open && (
        <Modal title="Add venue" onClose={() => setOpen(false)}>
          <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Main Sports Complex" /></Field>
          <Field label="Address"><Input value={address} onChange={(e) => setAddress(e.target.value)} /></Field>
          <Field label="City"><Input value={city} onChange={(e) => setCity(e.target.value)} /></Field>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={!name || create.isPending} onClick={() => create.mutate({ event_id: eventId, name, address: address || undefined, city: city || undefined })}>Add venue</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
