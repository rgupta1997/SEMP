import { useState } from 'react';
import { useEvent } from './EventLayout';
import { api } from '../../lib/api';
import { useApi, useApiMutation, fmtDateTime } from '../../lib/hooks';
import { Avatar, Badge, BulkBar, Button, Checkbox, EmptyState, Modal, StatusBadge, Table } from '../../components/ui';

export function ApprovalsPage() {
  const { eventId } = useEvent();
  const path = `/events/${eventId}/enrollments`;
  const { data: rows = [], isLoading } = useApi<any[]>(path);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [rejecting, setRejecting] = useState<any | null>(null);
  const [note, setNote] = useState('');
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const review = useApiMutation(
    ({ id, status, rejection_note }: any) => api('PATCH', `/event-institutions/${id}`, { status, rejection_note }),
    [path],
    () => { setRejecting(null); setNote(''); },
  );
  // Bulk review runs the PATCHes in parallel then refetches once.
  const bulkReview = useApiMutation(
    async ({ ids, status }: { ids: string[]; status: string }) => {
      await Promise.all(ids.map((id) => api('PATCH', `/event-institutions/${id}`, { status })));
    },
    [path],
    () => setSelected(new Set()),
  );

  const counts = {
    pending: rows.filter((r) => r.status === 'pending').length,
    approved: rows.filter((r) => r.status === 'approved').length,
    rejected: rows.filter((r) => r.status === 'rejected').length,
  };
  const visible = filter === 'all' ? rows : rows.filter((r) => r.status === filter);
  const selectableIds = visible.map((r) => r.id);
  const allSelected = selectableIds.length > 0 && selectableIds.every((id) => selected.has(id));

  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(selectableIds));

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(['pending', 'approved', 'rejected', 'all'] as const).map((f) => (
          <button key={f} onClick={() => { setFilter(f); setSelected(new Set()); }}
            className={`rounded-full px-3 py-1.5 text-sm font-semibold capitalize ${filter === f ? 'bg-brand-500 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50'}`}>
            {f}{f !== 'all' && counts[f] ? ` · ${counts[f]}` : ''}
          </button>
        ))}
      </div>

      <BulkBar count={selected.size} onClear={() => setSelected(new Set())}>
        <Button size="sm" disabled={bulkReview.isPending}
          onClick={() => bulkReview.mutate({ ids: [...selected], status: 'approved' }, { onError: (e: any) => alert(e.message) })}>
          Approve selected
        </Button>
        <Button size="sm" variant="outline" disabled={bulkReview.isPending}
          onClick={() => bulkReview.mutate({ ids: [...selected], status: 'rejected' }, { onError: (e: any) => alert(e.message) })}>
          Reject selected
        </Button>
      </BulkBar>

      {isLoading ? null : visible.length === 0 ? (
        <EmptyState icon="✓" title="Nothing here" description={filter === 'pending' ? 'No institutions are waiting for approval.' : `No ${filter} institutions.`} />
      ) : (
        <Table>
          <thead className="bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3 w-px"><Checkbox checked={allSelected} indeterminate={selected.size > 0} onChange={toggleAll} /></th>
              <th className="px-4 py-3">Institution</th>
              <th className="px-4 py-3">Applied</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((r) => (
              <tr key={r.id} className={`border-t border-slate-100 ${selected.has(r.id) ? 'bg-brand-50/50' : ''}`}>
                <td className="px-4 py-3"><Checkbox checked={selected.has(r.id)} onChange={() => toggle(r.id)} /></td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <Avatar name={r.institutions?.name} size={34} />
                    <div>
                      <div className="font-medium text-slate-800">{r.institutions?.name}</div>
                      <div className="text-xs text-slate-500">{[r.institutions?.code, r.institutions?.city].filter(Boolean).join(' · ') || '—'}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-sm text-slate-500">{fmtDateTime(r.applied_at)}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    {r.status !== 'approved' && (
                      <Button size="sm" onClick={() => review.mutate({ id: r.id, status: 'approved' })} disabled={review.isPending}>Approve</Button>
                    )}
                    {r.status !== 'rejected' && (
                      <Button size="sm" variant="outline" onClick={() => setRejecting(r)}>Reject</Button>
                    )}
                    {r.status === 'rejected' && r.rejection_note && <Badge tone="rose">{r.rejection_note}</Badge>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}

      {rejecting && (
        <Modal title={`Reject ${rejecting.institutions?.name}`} onClose={() => setRejecting(null)}>
          <p className="mb-3 text-sm text-slate-500">Optionally tell the institution why so they can fix and reapply.</p>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder="Reason (optional)…"
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
          <div className="mt-3 flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setRejecting(null)}>Cancel</Button>
            <Button variant="danger" disabled={review.isPending}
              onClick={() => review.mutate({ id: rejecting.id, status: 'rejected', rejection_note: note || undefined })}>Reject</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
