import { useState } from 'react';
import { useEvent } from './EventLayout';
import { useApi } from '../../lib/hooks';
import { Card, Spinner, Badge, Input, Avatar } from '../../components/ui';

interface Participant {
  id: string;
  name: string;
  email: string;
  phone?: string;
  institution?: { id: string; name: string; short_name?: string };
  teams: Array<{ team_id: string; team_name: string; sport?: { name: string; icon?: string }; role: string; jersey_number?: number }>;
}

export function EventParticipantsPage() {
  const { eventId } = useEvent();
  const { data: participants, isLoading } = useApi<Participant[]>(`/events/${eventId}/participants`);
  const [search, setSearch] = useState('');

  if (isLoading) return <div className="grid h-40 place-items-center"><Spinner /></div>;

  const filtered = participants?.filter((p) =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.email.toLowerCase().includes(search.toLowerCase()) ||
    p.institution?.name.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  const byInstitution = new Map<string, Participant[]>();
  for (const p of filtered) {
    const instId = p.institution?.id || 'unaffiliated';
    if (!byInstitution.has(instId)) byInstitution.set(instId, []);
    byInstitution.get(instId)!.push(p);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Participants</h2>
          <p className="text-sm text-slate-500">
            {participants?.length || 0} participants from {byInstitution.size} institutions
          </p>
        </div>
        <Input
          placeholder="Search by name, email, institution..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-64"
        />
      </div>

      {byInstitution.size === 0 ? (
        <Card className="p-8 text-center text-slate-500">
          No participants yet. Participants will appear here once institutions create teams and add players.
        </Card>
      ) : (
        [...byInstitution.entries()].map(([instId, members]) => {
          const inst = members[0]?.institution;
          return (
            <Card key={instId} className="overflow-hidden">
              <div className="border-b border-slate-100 bg-slate-50 px-4 py-3">
                <div className="flex items-center justify-between">
                  <div className="font-semibold text-slate-800">
                    {inst?.name || 'Unaffiliated'}
                    {inst?.short_name && <span className="ml-2 text-slate-500">({inst.short_name})</span>}
                  </div>
                  <Badge variant="muted">{members.length} players</Badge>
                </div>
              </div>
              <table className="min-w-full divide-y divide-slate-100 text-sm">
                <thead className="bg-slate-50/50">
                  <tr>
                    <th className="px-4 py-2 text-left font-semibold text-slate-600">Player</th>
                    <th className="px-4 py-2 text-left font-semibold text-slate-600">Contact</th>
                    <th className="px-4 py-2 text-left font-semibold text-slate-600">Teams</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {members.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50">
                      <td className="px-4 py-2">
                        <div className="flex items-center gap-2">
                          <Avatar name={p.name} size={28} />
                          <span className="font-medium text-slate-800">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2 text-slate-600">
                        <div>{p.email}</div>
                        {p.phone && <div className="text-xs text-slate-400">{p.phone}</div>}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex flex-wrap gap-1">
                          {p.teams.map((t) => (
                            <Badge key={t.team_id} variant="muted" className="text-xs">
                              {t.sport?.icon || '🏅'} {t.team_name}
                              {t.jersey_number && ` #${t.jersey_number}`}
                            </Badge>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          );
        })
      )}
    </div>
  );
}
