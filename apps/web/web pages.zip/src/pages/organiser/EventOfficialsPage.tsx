import { useState } from 'react';
import { useEvent } from './EventLayout';
import { useApi, useApiMutation, fmtDate } from '../../lib/hooks';
import { api } from '../../lib/api';
import { Card, Spinner, Badge, Button, Input, Avatar, Modal } from '../../components/ui';

interface Official {
  id: string;
  user: { id: string; name: string; email: string; phone?: string };
  assigned_by?: { id: string; name: string };
  assigned_at: string;
  notes?: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  account_type?: string;
}

function AssignOfficialModal({ eventId, existingIds, onClose }: { eventId: string; existingIds: Set<string>; onClose: () => void }) {
  const [search, setSearch] = useState('');
  const { data: users, isLoading } = useApi<User[]>('/users?account_type=official');
  const assignMut = useApiMutation(
    (userId: string) => api('POST', `/events/${eventId}/officials`, { user_id: userId }),
    [`/events/${eventId}/officials`],
  );

  const available = users?.filter((u) => !existingIds.has(u.id) && 
    (u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()))
  ) ?? [];

  return (
    <Modal title="Assign Official to Event" onClose={onClose}>
      <div className="space-y-4">
        <Input
          placeholder="Search officials by name or email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          autoFocus
        />

        {isLoading ? (
          <div className="grid h-20 place-items-center"><Spinner /></div>
        ) : available.length === 0 ? (
          <p className="text-center text-sm text-slate-500 py-4">
            {search ? 'No matching officials found' : 'All officials are already assigned to this event'}
          </p>
        ) : (
          <div className="max-h-64 overflow-auto rounded-lg border border-slate-200">
            {available.map((u) => (
              <div key={u.id} className="flex items-center justify-between border-b border-slate-100 px-3 py-2 last:border-b-0 hover:bg-slate-50">
                <div className="flex items-center gap-2">
                  <Avatar name={u.name} size={28} />
                  <div>
                    <div className="text-sm font-medium text-slate-800">{u.name}</div>
                    <div className="text-xs text-slate-500">{u.email}</div>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => assignMut.mutate(u.id, { onSuccess: onClose })}
                  disabled={assignMut.isPending}
                >
                  Assign
                </Button>
              </div>
            ))}
          </div>
        )}

        <p className="text-xs text-slate-500">
          Officials must first be created with the "official" account type in Platform → Users before they can be assigned to events.
        </p>
      </div>
    </Modal>
  );
}

export function EventOfficialsPage() {
  const { eventId } = useEvent();
  const { data: officials, isLoading } = useApi<Official[]>(`/events/${eventId}/officials`);
  const [assigning, setAssigning] = useState(false);
  const removeMut = useApiMutation(
    (officialId: string) => api('DELETE', `/events/${eventId}/officials/${officialId}`),
    [`/events/${eventId}/officials`],
  );

  if (isLoading) return <div className="grid h-40 place-items-center"><Spinner /></div>;

  const existingIds = new Set(officials?.map((o) => o.user.id) ?? []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Officials</h2>
          <p className="text-sm text-slate-500">
            {officials?.length || 0} officials assigned to this event
          </p>
        </div>
        <Button onClick={() => setAssigning(true)}>+ Assign Official</Button>
      </div>

      {officials && officials.length > 0 ? (
        <Card className="overflow-hidden">
          <table className="min-w-full divide-y divide-slate-200 text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Official</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Contact</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Assigned</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Notes</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {officials.map((o) => (
                <tr key={o.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Avatar name={o.user.name} size={32} />
                      <span className="font-medium text-slate-900">{o.user.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-slate-600">{o.user.email}</div>
                    {o.user.phone && <div className="text-xs text-slate-400">{o.user.phone}</div>}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    <div>{fmtDate(o.assigned_at)}</div>
                    {o.assigned_by && <div className="text-xs text-slate-400">by {o.assigned_by.name}</div>}
                  </td>
                  <td className="px-4 py-3 text-slate-500">{o.notes || '—'}</td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-rose-600 hover:bg-rose-50 hover:text-rose-700"
                      onClick={() => {
                        if (confirm(`Remove ${o.user.name} from this event?`)) {
                          removeMut.mutate(o.id);
                        }
                      }}
                      disabled={removeMut.isPending}
                    >
                      Remove
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : (
        <Card className="p-8 text-center text-slate-500">
          <div className="text-4xl mb-3">⚑</div>
          <div className="font-medium text-slate-700 mb-1">No officials assigned yet</div>
          <p className="text-sm mb-4">
            Assign officials to this event so they can score matches and manage fixtures.
          </p>
          <Button onClick={() => setAssigning(true)}>+ Assign Official</Button>
        </Card>
      )}

      <Card className="bg-slate-50 p-4">
        <div className="flex items-center gap-3 text-sm text-slate-600">
          <span className="text-lg">ℹ️</span>
          <span>
            Officials assigned to this event will see this event's fixtures in their "My Matches" view and can score assigned matches.
            Each event has its own set of officials for proper multi-tenant isolation.
          </span>
        </div>
      </Card>

      {assigning && <AssignOfficialModal eventId={eventId} existingIds={existingIds} onClose={() => setAssigning(false)} />}
    </div>
  );
}
