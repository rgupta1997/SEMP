import { Link } from 'react-router-dom';
import { useEvent } from './EventLayout';
import { useApi } from '../../lib/hooks';
import { Button, Card, CardBody, CardHeader, StatCard, StatusBadge } from '../../components/ui';

export function EventDashboard() {
  const { event, eventId } = useEvent();
  const { data: tournaments = [] } = useApi<any[]>(`/tournaments?event_id=${eventId}`);
  const { data: teams = [] } = useApi<any[]>(`/teams?event_id=${eventId}`);
  const { data: venues = [] } = useApi<any[]>(`/venues?event_id=${eventId}`);
  const { data: enrollments = [] } = useApi<any[]>(`/events/${eventId}/enrollments`);

  const pending = enrollments.filter((e) => e.status === 'pending');
  const approved = enrollments.filter((e) => e.status === 'approved');

  const tasks: { label: string; to: string; tone: 'amber' | 'brand' }[] = [];
  if (pending.length) tasks.push({ label: `${pending.length} institution${pending.length > 1 ? 's' : ''} awaiting approval`, to: `/events/${eventId}/approvals`, tone: 'amber' });
  if (tournaments.length === 0) tasks.push({ label: 'No tournament yet — add one to start configuring sports', to: `/events/${eventId}/setup`, tone: 'brand' });
  if (venues.length === 0) tasks.push({ label: 'No venues added yet', to: `/events/${eventId}/setup`, tone: 'brand' });
  if (event.status === 'draft') tasks.push({ label: 'Event is in draft — open registration when setup is ready', to: `/events/${eventId}/settings`, tone: 'brand' });

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Tournaments" value={tournaments.length} />
        <StatCard label="Teams" value={teams.length} hint={`${approved.length} institutions approved`} />
        <StatCard label="Pending approvals" value={pending.length} accent={pending.length > 0} hint="needs review" />
        <StatCard label="Venues" value={venues.length} />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <Card>
          <CardHeader title="Needs your attention" subtitle="Open items blocking progress" />
          <CardBody>
            {tasks.length === 0 ? (
              <p className="rounded-xl bg-emerald-50 px-4 py-6 text-center text-sm font-medium text-emerald-700">All clear — everything is running smoothly.</p>
            ) : (
              <div className="space-y-2">
                {tasks.map((t, i) => (
                  <Link key={i} to={t.to} className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-3 hover:border-brand-300 hover:bg-brand-50">
                    <span className="flex items-center gap-3">
                      <span className={`h-2 w-2 rounded-full ${t.tone === 'amber' ? 'bg-amber-500' : 'bg-brand-500'}`} />
                      <span className="text-sm font-medium text-slate-700">{t.label}</span>
                    </span>
                    <span className="text-sm text-slate-400">→</span>
                  </Link>
                ))}
              </div>
            )}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Tournaments" action={<Link to={`/events/${eventId}/setup`}><Button size="sm" variant="subtle">Manage</Button></Link>} />
          <CardBody>
            {tournaments.length === 0 ? (
              <p className="text-sm text-slate-400">No tournaments yet.</p>
            ) : (
              <div className="space-y-2">
                {tournaments.map((t) => (
                  <div key={t.id} className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2.5">
                    <span className="text-sm font-medium text-slate-800">{t.name}</span>
                    <StatusBadge status={t.status} />
                  </div>
                ))}
              </div>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
