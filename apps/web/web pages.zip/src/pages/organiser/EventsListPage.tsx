import { useNavigate } from 'react-router-dom';
import { useApi, fmtDateRange } from '../../lib/hooks';
import { Button, Card, EmptyState, PageHeader, Spinner, StatusBadge } from '../../components/ui';

interface Event { id: string; name: string; slug: string; status: string; venue?: string; start_date: string; end_date: string; description?: string }

export function EventsListPage() {
  const navigate = useNavigate();
  const { data: events = [], isLoading } = useApi<Event[]>('/events');

  return (
    <div>
      <PageHeader title="Events" subtitle="Every event you organise, from draft to wrapped up.">
        <Button onClick={() => navigate('/events/new')}>+ Create event</Button>
      </PageHeader>

      {isLoading ? <Spinner /> : events.length === 0 ? (
        <EmptyState icon="◆" title="No events yet" description="Create your first event to build tournaments, open registration and run match day."
          action={<Button onClick={() => navigate('/events/new')}>+ Create event</Button>} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {events.map((e) => (
            <Card key={e.id} className="cursor-pointer transition hover:border-brand-300 hover:shadow-md" onClick={() => navigate(`/events/${e.id}`)}>
              <div className="flex h-24 items-end justify-between rounded-t-2xl bg-gradient-to-br from-brand-500 to-brand-700 p-4">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-white/20 text-xl font-black text-white">
                  {e.name.slice(0, 1)}
                </span>
                <StatusBadge status={e.status} />
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-slate-900">{e.name}</h3>
                <p className="mt-1 text-sm text-slate-500">{e.venue || 'Venue TBD'} · {fmtDateRange(e.start_date, e.end_date)}</p>
                {e.description && <p className="mt-2 line-clamp-2 text-sm text-slate-400">{e.description}</p>}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
