import { useState } from 'react';
import { useEvent } from './EventLayout';
import { api } from '../../lib/api';
import { useApi, useApiMutation, fmtDateTime } from '../../lib/hooks';
import { Button, Card, EmptyState, Field, Modal, Select, Spinner, StatusBadge } from '../../components/ui';

interface Ground { id: string; name: string; venues?: { name?: string } }
interface Official { id: string; name: string; account_type: string }

function toLocalInput(d?: string | null): string {
  if (!d) return '';
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return '';
  const off = date.getTimezoneOffset();
  return new Date(date.getTime() - off * 60000).toISOString().slice(0, 16);
}

function ScheduleModal({ fixture, drawPath, grounds, officials, teamName, onClose }:
  { fixture: any; drawPath: string; grounds: Ground[]; officials: Official[]; teamName: (id: string | null) => string; onClose: () => void }) {
  const [groundId, setGroundId] = useState(fixture.venue_ground_id ?? '');
  const [when, setWhen] = useState(toLocalInput(fixture.scheduled_at));
  const [officialId, setOfficialId] = useState(fixture.official_id ?? '');

  const save = useApiMutation(
    (body: any) => api('PATCH', `/fixtures/${fixture.id}`, body),
    [drawPath],
    onClose,
  );

  return (
    <Modal title={`Schedule · ${teamName(fixture.home_team_id)} vs ${teamName(fixture.away_team_id)}`} onClose={onClose}>
      <Field label="Ground / court">
        <Select value={groundId} onChange={(e) => setGroundId(e.target.value)}>
          <option value="">— unassigned —</option>
          {grounds.map((g) => <option key={g.id} value={g.id}>{g.venues?.name ? `${g.venues.name} · ` : ''}{g.name}</option>)}
        </Select>
      </Field>
      <Field label="Date & time">
        <input type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)}
          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand-400" />
      </Field>
      <Field label="Match official" hint={officials.length === 0 ? 'No officials yet — add users with the Official account type.' : undefined}>
        <Select value={officialId} onChange={(e) => setOfficialId(e.target.value)}>
          <option value="">— unassigned —</option>
          {officials.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
        </Select>
      </Field>
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button disabled={save.isPending}
          onClick={() => save.mutate({
            venue_ground_id: groundId || null,
            scheduled_at: when ? new Date(when).toISOString() : null,
            official_id: officialId || null,
          }, { onError: (e: any) => alert(e.message) })}>
          {save.isPending ? 'Saving…' : 'Save schedule'}
        </Button>
      </div>
    </Modal>
  );
}

function DrawCard({ td, sportName, teamName, grounds, officials }:
  { td: any; sportName: string; teamName: (id: string | null) => string; grounds: Ground[]; officials: Official[] }) {
  const path = `/tournament-disciplines/${td.id}/fixtures`;
  const { data: fixtures = [], isLoading } = useApi<any[]>(path);
  const generate = useApiMutation(() => api('POST', `/tournament-disciplines/${td.id}/fixtures/generate`, { params: {} }), [path]);
  const [editing, setEditing] = useState<any | null>(null);

  const groundLabel = (id: string | null) => { const g = grounds.find((x) => x.id === id); return g ? `${g.venues?.name ? g.venues.name + ' · ' : ''}${g.name}` : null; };
  const officialName = (id: string | null) => officials.find((o) => o.id === id)?.name ?? null;

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-semibold text-slate-900">{td.disciplines?.name ?? sportName}</div>
          <div className="text-xs text-slate-500">{td.entry_type} draw · {fixtures.length} fixture{fixtures.length === 1 ? '' : 's'}</div>
        </div>
        <Button size="sm" variant={fixtures.length ? 'outline' : 'primary'} disabled={generate.isPending}
          onClick={() => generate.mutate(undefined, { onError: (e: any) => alert(e.message) })}>
          {generate.isPending ? 'Generating…' : fixtures.length ? 'Regenerate' : 'Generate draw'}
        </Button>
      </div>
      <div className="mt-3">
        {isLoading ? <Spinner /> : fixtures.length === 0 ? (
          <p className="rounded-lg bg-slate-50 px-3 py-3 text-sm text-slate-400">No fixtures yet — generate the draw from registered teams.</p>
        ) : (
          <div className="space-y-1.5">
            {fixtures.map((f) => (
              <div key={f.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg bg-slate-50 px-3 py-2 text-sm">
                <span className="text-xs font-semibold uppercase tracking-wide text-slate-400 w-20">{f.round || 'Match'}</span>
                <span className="flex-1 min-w-[180px] font-medium text-slate-700">
                  {teamName(f.home_team_id)} <span className="text-slate-400">vs</span> {teamName(f.away_team_id)}
                </span>
                <span className="text-xs text-slate-500">
                  {groundLabel(f.venue_ground_id) ?? 'No ground'} · {f.scheduled_at ? fmtDateTime(f.scheduled_at) : 'Unscheduled'}
                  {officialName(f.official_id) ? ` · ${officialName(f.official_id)}` : ' · No official'}
                </span>
                <StatusBadge status={f.status} />
                {f.home_team_id && f.away_team_id && (
                  <Button size="sm" variant="ghost" onClick={() => setEditing(f)}>Schedule</Button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      {editing && <ScheduleModal fixture={editing} drawPath={path} grounds={grounds} officials={officials} teamName={teamName} onClose={() => setEditing(null)} />}
    </Card>
  );
}

function SportBlock({ ts, sportName, teamName, grounds, officials }:
  { ts: any; sportName: string; teamName: (id: string | null) => string; grounds: Ground[]; officials: Official[] }) {
  const { data: draws = [] } = useApi<any[]>(`/tournament-disciplines?tournament_sport_id=${ts.id}`);
  if (draws.length === 0) return null;
  return (
    <div>
      <h3 className="mb-2 text-sm font-bold uppercase tracking-wide text-slate-500">{sportName}</h3>
      <div className="grid gap-3">
        {draws.map((td) => <DrawCard key={td.id} td={td} sportName={sportName} teamName={teamName} grounds={grounds} officials={officials} />)}
      </div>
    </div>
  );
}

export function SchedulePage() {
  const { eventId } = useEvent();
  const { data: tournaments = [] } = useApi<any[]>(`/tournaments?event_id=${eventId}`);
  const [tournamentId, setTournamentId] = useState('');
  const active = tournamentId || tournaments[0]?.id || '';
  const { data: tsports = [] } = useApi<any[]>(active ? `/tournament-sports?tournament_id=${active}` : null);
  const { data: sports = [] } = useApi<any[]>('/sports');
  const { data: teams = [] } = useApi<any[]>(`/teams?event_id=${eventId}`);
  const { data: grounds = [] } = useApi<Ground[]>(`/events/${eventId}/grounds`);
  const { data: officials = [] } = useApi<Official[]>('/users?account_type=official');

  const sportName = (id: string) => sports.find((s) => s.id === id)?.name ?? 'Sport';
  const teamName = (id: string | null) => (id ? teams.find((t) => t.id === id)?.name ?? 'TBD' : 'TBD');

  if (tournaments.length === 0) {
    return <EmptyState icon="⚑" title="No tournaments" description="Set up a tournament and its sports before generating fixtures." />;
  }

  return (
    <div>
      <div className="mb-4">
        <label className="flex items-center gap-2 text-sm">
          <span className="font-semibold text-slate-600">Tournament</span>
          <Select value={active} onChange={(e) => setTournamentId(e.target.value)} className="w-56">
            {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
        </label>
      </div>
      {tsports.length === 0 ? (
        <EmptyState icon="⚑" title="No sports configured" description="Add sports & disciplines in Setup, then come back to generate fixtures." />
      ) : (
        <div className="space-y-6">
          {tsports.map((ts) => <SportBlock key={ts.id} ts={ts} sportName={sportName(ts.sport_id)} teamName={teamName} grounds={grounds} officials={officials} />)}
        </div>
      )}
    </div>
  );
}
