import { NavLink, Outlet, useNavigate, useOutletContext, useParams } from 'react-router-dom';
import { api } from '../../lib/api';
import { useApi, useApiMutation, fmtDateRange } from '../../lib/hooks';
import { Button, cn, Spinner, StatusBadge } from '../../components/ui';

export interface EventDetail {
  id: string; name: string; slug: string; status: string;
  venue?: string; description?: string; start_date: string; end_date: string;
}
interface EventCtx { event: EventDetail; eventId: string }
export const useEvent = () => useOutletContext<EventCtx>();

const TABS = [
  { to: '', label: 'Overview', end: true },
  { to: 'setup', label: 'Setup' },
  { to: 'approvals', label: 'Approvals' },
  { to: 'participants', label: 'Participants' },
  { to: 'officials', label: 'Officials' },
  { to: 'schedule', label: 'Schedule' },
  { to: 'standings', label: 'Standings' },
  { to: 'settings', label: 'Settings' },
];

// The legal "next" status + button label for the go-live flow.
const NEXT_STATUS: Record<string, { to: string; label: string } | null> = {
  draft: { to: 'registration_open', label: 'Open registration' },
  registration_open: { to: 'ongoing', label: 'Start event' },
  ongoing: { to: 'completed', label: 'Mark completed' },
  completed: null,
};

export function EventLayout() {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { data: event, isLoading } = useApi<EventDetail>(`/events/${eventId}`);
  const statusMut = useApiMutation(
    (status: string) => api('PATCH', `/events/${eventId}/status`, { status }),
    [`/events/${eventId}`, '/events'],
  );

  if (isLoading || !event) return <Spinner />;
  const next = NEXT_STATUS[event.status];

  return (
    <div>
      <button onClick={() => navigate('/events')} className="mb-3 text-sm font-medium text-slate-500 hover:text-slate-800">← All events</button>
      <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">{event.name}</h1>
            <StatusBadge status={event.status} />
          </div>
          <p className="mt-1 text-sm text-slate-500">{event.venue || 'Venue TBD'} · {fmtDateRange(event.start_date, event.end_date)}</p>
        </div>
        {next && (
          <Button
            onClick={() => statusMut.mutate(next.to, { onError: (e: any) => alert(e.message) })}
            disabled={statusMut.isPending}
          >
            {statusMut.isPending ? 'Updating…' : next.label} →
          </Button>
        )}
      </div>

      <div className="mb-6 flex gap-1 overflow-x-auto border-b border-slate-200">
        {TABS.map((t) => (
          <NavLink
            key={t.to || 'overview'}
            to={t.to}
            end={t.end}
            className={({ isActive }) => cn(
              '-mb-px whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors',
              isActive ? 'border-brand-500 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-800',
            )}
          >
            {t.label}
          </NavLink>
        ))}
      </div>

      <Outlet context={{ event, eventId: eventId! } satisfies EventCtx} />
    </div>
  );
}
