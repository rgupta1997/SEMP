import { useNavigate } from 'react-router-dom';
import { useApi, fmtDateTime } from '../../lib/hooks';
import { Button, Card, EmptyState, PageHeader, Spinner, StatCard, StatusBadge } from '../../components/ui';
import { awayTeam, disciplineLabel, eventLabel, homeTeam, teamLabel, venueLabel } from './fixtureHelpers';

export function OfficialFixturesPage() {
  const navigate = useNavigate();
  const { data: fixtures = [], isLoading } = useApi<any[]>('/me/officiating');

  const live = fixtures.filter((f) => f.status === 'live').length;
  const upcoming = fixtures.filter((f) => f.status === 'scheduled').length;
  const done = fixtures.filter((f) => f.status === 'completed').length;

  return (
    <div>
      <PageHeader title="My matches" subtitle="Fixtures assigned to you to officiate." />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Live now" value={live} accent={live > 0} />
        <StatCard label="Upcoming" value={upcoming} />
        <StatCard label="Completed" value={done} />
      </div>

      {isLoading ? <Spinner /> : fixtures.length === 0 ? (
        <EmptyState icon="⚑" title="No matches assigned" description="When an organiser assigns you to a fixture, it shows up here." />
      ) : (
        <div className="space-y-3">
          {fixtures.map((f) => (
            <Card key={f.id} className="flex flex-wrap items-center justify-between gap-4 p-4">
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                  <span>{disciplineLabel(f)}</span>
                  {f.round && <span className="rounded bg-slate-100 px-1.5 py-0.5 text-slate-500">{f.round}</span>}
                </div>
                <div className="mt-1 text-lg font-bold text-slate-900">
                  {teamLabel(homeTeam(f))} <span className="text-slate-300">vs</span> {teamLabel(awayTeam(f))}
                </div>
                <div className="mt-0.5 text-sm text-slate-500">{eventLabel(f)} · {venueLabel(f)} · {fmtDateTime(f.scheduled_at)}</div>
              </div>
              <div className="flex items-center gap-3">
                <StatusBadge status={f.status} />
                <Button onClick={() => navigate(`/official/score/${f.id}`)}>Open console →</Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
