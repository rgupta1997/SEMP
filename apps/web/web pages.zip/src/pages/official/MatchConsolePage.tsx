import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../../lib/api';
import { useApi, useApiMutation, fmtDateTime } from '../../lib/hooks';
import { Button, Card, CardBody, CardHeader, EmptyState, Input, Spinner, StatusBadge, Textarea } from '../../components/ui';
import { awayTeam, disciplineLabel, eventLabel, homeTeam, teamLabel, venueLabel } from './fixtureHelpers';

const SECONDARY: { status: string; label: string; variant: 'outline' | 'danger' }[] = [
  { status: 'walkover', label: 'Walkover', variant: 'outline' },
  { status: 'postponed', label: 'Postpone', variant: 'outline' },
  { status: 'cancelled', label: 'Cancel match', variant: 'danger' },
];

export function MatchConsolePage() {
  const { fixtureId } = useParams();
  const navigate = useNavigate();
  const { data: fixtures = [], isLoading } = useApi<any[]>('/me/officiating');
  const fixture = fixtures.find((f) => f.id === fixtureId);

  const [home, setHome] = useState('');
  const [away, setAway] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (fixture) {
      setHome(fixture.home_score != null ? String(fixture.home_score) : '');
      setAway(fixture.away_score != null ? String(fixture.away_score) : '');
      setNotes(fixture.notes ?? '');
    }
  }, [fixture?.id]);

  const setStatus = useApiMutation((status: string) => api('PATCH', `/fixtures/${fixtureId}`, { status }), ['/me/officiating']);
  const saveResult = useApiMutation((body: any) => api('PATCH', `/fixtures/${fixtureId}/result`, body), ['/me/officiating']);

  if (isLoading) return <Spinner />;
  if (!fixture) return <EmptyState icon="⚑" title="Match not found" description="This fixture is not assigned to you." action={<Button onClick={() => navigate('/official')}>Back to matches</Button>} />;

  const homeName = teamLabel(homeTeam(fixture));
  const awayName = teamLabel(awayTeam(fixture));
  const hs = home === '' ? null : Number(home);
  const as = away === '' ? null : Number(away);
  const winnerLabel = hs == null || as == null ? '—' : hs > as ? homeName : as > hs ? awayName : 'Draw';
  const isLive = fixture.status === 'live';

  const submitResult = (status: 'live' | 'completed') => {
    const winner_team_id = hs != null && as != null && hs !== as ? (hs > as ? fixture.home_team_id : fixture.away_team_id) : null;
    saveResult.mutate(
      { home_score: hs, away_score: as, winner_team_id, status, notes: notes || undefined },
      { onError: (e: any) => alert(e.message) },
    );
  };

  return (
    <div>
      <button onClick={() => navigate('/official')} className="mb-3 text-sm font-medium text-slate-500 hover:text-slate-800">← My matches</button>

      <Card className="mb-6 overflow-hidden">
        <div className="bg-slate-900 px-6 py-5 text-white">
          <div className="flex items-center justify-between text-xs font-semibold uppercase tracking-wide text-slate-400">
            <span>{disciplineLabel(fixture)} {fixture.round ? `· ${fixture.round}` : ''}</span>
            <StatusBadge status={fixture.status} />
          </div>
          <div className="mt-4 flex items-center justify-center gap-6 text-center">
            <div className="flex-1"><div className="text-xl font-bold">{homeName}</div><div className="text-xs text-slate-400">Home</div></div>
            <div className="flex items-center gap-3 text-4xl font-black tabular-nums">
              <span>{fixture.home_score ?? '–'}</span><span className="text-slate-600">:</span><span>{fixture.away_score ?? '–'}</span>
            </div>
            <div className="flex-1"><div className="text-xl font-bold">{awayName}</div><div className="text-xs text-slate-400">Away</div></div>
          </div>
          <div className="mt-4 text-center text-sm text-slate-400">{eventLabel(fixture)} · {venueLabel(fixture)} · {fmtDateTime(fixture.scheduled_at)}</div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader title="Enter result" subtitle="Record the score — the winner is derived automatically." />
          <CardBody>
            <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-3">
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-slate-600">{homeName}</span>
                <Input type="number" min={0} value={home} onChange={(e) => setHome(e.target.value)} className="text-center text-lg font-bold" />
              </label>
              <span className="pb-2 text-lg font-black text-slate-400">:</span>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold text-slate-600">{awayName}</span>
                <Input type="number" min={0} value={away} onChange={(e) => setAway(e.target.value)} className="text-center text-lg font-bold" />
              </label>
            </div>
            <div className="mt-3 rounded-lg bg-slate-50 px-3 py-2 text-sm">
              <span className="text-slate-500">Winner: </span><span className="font-semibold text-slate-800">{winnerLabel}</span>
            </div>
            <div className="mt-4">
              <span className="mb-1.5 block text-xs font-semibold text-slate-600">Result note</span>
              <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="MoM, remarks, walkover reason…" />
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <Button variant="outline" disabled={saveResult.isPending} onClick={() => submitResult('live')}>Save (keep live)</Button>
              <Button disabled={saveResult.isPending} onClick={() => submitResult('completed')}>{saveResult.isPending ? 'Saving…' : 'Save & complete'}</Button>
            </div>
          </CardBody>
        </Card>

        <Card className="h-fit">
          <CardHeader title="Match control" />
          <CardBody className="space-y-2">
            <Button variant={isLive ? 'outline' : 'primary'} className="w-full justify-start" disabled={setStatus.isPending || isLive}
              onClick={() => setStatus.mutate('live', { onError: (e: any) => alert(e.message) })}>
              {isLive ? '✓ Match is live' : 'Start match (go live)'}
            </Button>
            {SECONDARY.map((s) => (
              <Button key={s.status} variant={s.variant} className="w-full justify-start" disabled={setStatus.isPending || fixture.status === s.status}
                onClick={() => setStatus.mutate(s.status, { onError: (e: any) => alert(e.message) })}>
                {fixture.status === s.status ? `✓ ${s.label}` : s.label}
              </Button>
            ))}
            <p className="pt-2 text-xs text-slate-400">Completing with a score updates standings automatically.</p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
