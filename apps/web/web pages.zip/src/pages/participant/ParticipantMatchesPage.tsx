import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApi } from '../../lib/hooks';
import { EmptyState, PageHeader, Select, Spinner } from '../../components/ui';
import { MatchRow } from '../../components/participant/MatchRow';
import type { MatchSummary } from '../../components/participant/types';

interface MatchesResponse { matches: MatchSummary[]; total: number }

const STATUS_OPTIONS = [
  { value: '', label: 'All statuses' },
  { value: 'scheduled', label: 'Scheduled' },
  { value: 'live', label: 'Live' },
  { value: 'completed', label: 'Completed' },
];

export function ParticipantMatchesPage() {
  const [eventId, setEventId] = useState('');
  const [status, setStatus] = useState('');

  const qs = new URLSearchParams();
  if (eventId) qs.set('event_id', eventId);
  if (status) qs.set('status', status);
  const path = `/me/matches${qs.toString() ? `?${qs}` : ''}`;
  const { data, isLoading } = useApi<MatchesResponse>(path);
  const matches = data?.matches ?? [];

  // Build the event filter from whatever the unfiltered set returns first.
  const allMatches = useApi<MatchesResponse>('/me/matches').data?.matches ?? [];
  const events = useMemo(() => {
    const map = new Map<string, string>();
    for (const m of allMatches) if (m.event) map.set(m.event.id, m.event.name);
    return [...map.entries()];
  }, [allMatches]);

  return (
    <div className="space-y-5">
      <PageHeader title="All matches" subtitle="Every match across your events.">
        <Link to="/me" className="text-sm font-semibold text-brand-600 hover:text-brand-700">← Dashboard</Link>
      </PageHeader>

      <div className="flex flex-wrap gap-3">
        <Select value={eventId} onChange={(e) => setEventId(e.target.value)} className="w-auto">
          <option value="">All events</option>
          {events.map(([id, name]) => <option key={id} value={id}>{name}</option>)}
        </Select>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} className="w-auto">
          {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </Select>
      </div>

      {isLoading ? <Spinner /> : matches.length === 0 ? (
        <EmptyState icon="⚑" title="No matches found" description="Try clearing the filters above." />
      ) : (
        <div className="space-y-2">
          {matches.map((m) => <MatchRow key={m.id} match={m} />)}
        </div>
      )}
    </div>
  );
}
