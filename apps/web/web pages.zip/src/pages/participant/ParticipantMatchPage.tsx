import type { ReactNode } from 'react';
import { Link, useParams } from 'react-router-dom';
import { useApi, fmtDateTime } from '../../lib/hooks';
import { Card, CardBody, CardHeader, EmptyState, Spinner, StatusBadge } from '../../components/ui';
import { ResultBadge } from '../../components/participant/ResultBadge';
import type { MatchResult } from '../../components/participant/types';

interface MatchDetail {
  fixture: {
    id: string;
    round: string | null;
    status: string;
    scheduled_at: string | null;
    duration_minutes: number | null;
    notes: string | null;
    home_score: number | null;
    away_score: number | null;
    my_score: number | null;
    opp_score: number | null;
    result: MatchResult;
    venue: { ground: string | null; venue_name: string | null; city: string | null } | null;
    sport: string | null;
    discipline: string | null;
    tournament: string | null;
    event: { id: string; name: string; slug: string } | null;
    my_team: { id: string; name: string; institution: string | null };
    opponent: { id: string; name: string; institution: string | null } | null;
    my_role: string | null;
    jersey_number: number | null;
    teammates: { name: string; role: string; jersey_number: number | null }[];
  };
}

function Detail({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex justify-between gap-4 py-1.5 text-sm">
      <span className="text-slate-500">{label}</span>
      <span className="text-right font-medium text-slate-800">{value || '—'}</span>
    </div>
  );
}

export function ParticipantMatchPage() {
  const { fixtureId } = useParams();
  const { data, isLoading, error } = useApi<MatchDetail>(`/me/matches/${fixtureId}`);

  if (isLoading) return <Spinner />;
  if (error || !data) {
    return <EmptyState icon="⚑" title="Match not available" description="This match doesn't exist or you're not part of it." />;
  }

  const f = data.fixture;
  const venue = f.venue ? [f.venue.ground, f.venue.venue_name, f.venue.city].filter(Boolean).join(', ') : null;
  const subtitle = [f.sport, f.discipline].filter(Boolean).join(' · ');

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        {f.event ? (
          <Link to={`/me/events/${f.event.id}`} className="text-sm font-semibold text-brand-600 hover:text-brand-700">← Back to event</Link>
        ) : (
          <Link to="/me/matches" className="text-sm font-semibold text-brand-600 hover:text-brand-700">← All matches</Link>
        )}
        <StatusBadge status={f.status} />
      </div>

      <Card>
        <CardBody className="pt-5">
          <div className="text-center text-xs font-semibold uppercase tracking-wide text-slate-400">
            {f.event?.name}{subtitle ? ` · ${subtitle}` : ''}
          </div>
          {f.round && <div className="mt-1 text-center text-sm text-slate-500">{f.round} · {fmtDateTime(f.scheduled_at)}</div>}

          <div className="mt-5 flex items-center justify-center gap-6">
            <div className="flex-1 text-right">
              <div className="font-bold text-slate-900">{f.my_team.name}</div>
              {f.my_team.institution && <div className="text-xs text-slate-400">{f.my_team.institution}</div>}
            </div>
            <div className="flex items-center gap-3 text-3xl font-black tabular-nums text-slate-900">
              <span>{f.my_score ?? '–'}</span>
              <span className="text-slate-300">:</span>
              <span>{f.opp_score ?? '–'}</span>
            </div>
            <div className="flex-1 text-left">
              <div className="font-bold text-slate-900">{f.opponent?.name ?? 'TBD'}</div>
              {f.opponent?.institution && <div className="text-xs text-slate-400">{f.opponent.institution}</div>}
            </div>
          </div>

          <div className="mt-4 flex justify-center">
            <ResultBadge result={f.result} />
          </div>
        </CardBody>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader title="Match details" />
          <CardBody className="pt-0">
            <Detail label="Tournament" value={f.tournament} />
            <Detail label="Venue" value={venue} />
            <Detail label="When" value={fmtDateTime(f.scheduled_at)} />
            <Detail label="Duration" value={f.duration_minutes ? `${f.duration_minutes} min` : null} />
            <Detail label="Your team" value={f.my_team.name} />
            <Detail label="Your role" value={[f.my_role?.replace(/_/g, ' '), f.jersey_number != null ? `#${f.jersey_number}` : null].filter(Boolean).join(' · ')} />
            {f.notes && <Detail label="Notes" value={f.notes} />}
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Your team" subtitle={f.my_team.name} />
          <CardBody className="pt-0">
            {f.teammates.length === 0 ? (
              <p className="text-sm text-slate-400">No roster recorded.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {f.teammates.map((t, i) => (
                  <li key={i} className="flex items-center justify-between py-2 text-sm">
                    <span className="font-medium text-slate-800">{t.name}</span>
                    <span className="text-slate-400">
                      {t.role?.replace(/_/g, ' ')}{t.jersey_number != null ? ` · #${t.jersey_number}` : ''}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}
