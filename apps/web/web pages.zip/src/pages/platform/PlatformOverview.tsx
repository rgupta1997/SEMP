import { useApi } from '../../lib/hooks';
import { Card, Spinner, Badge, cn } from '../../components/ui';

const STATUS_VARIANTS: Record<string, string> = {
  draft: 'bg-slate-100 text-slate-700',
  registration_open: 'bg-amber-100 text-amber-700',
  ongoing: 'bg-emerald-100 text-emerald-700',
  completed: 'bg-sky-100 text-sky-700',
};

export function PlatformOverview() {
  const { data: events, isLoading } = useApi<any[]>('/events');

  if (isLoading) return <div className="grid h-40 place-items-center"><Spinner /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Platform Overview</h1>
        <p className="mt-1 text-slate-500">Read-only view of all events across the platform</p>
      </div>

      {events && events.length > 0 ? (
        <Card className="overflow-hidden">
          <table className="min-w-full divide-y divide-slate-200 text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Event</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Status</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Location</th>
                <th className="px-4 py-3 text-left font-semibold text-slate-700">Dates</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {events.map((ev: any) => (
                <tr key={ev.id} className="hover:bg-slate-50">
                  <td className="px-4 py-3">
                    <div className="font-medium text-slate-900">{ev.name}</div>
                    {ev.tagline && <div className="text-xs text-slate-500">{ev.tagline}</div>}
                  </td>
                  <td className="px-4 py-3">
                    <Badge className={cn('capitalize', STATUS_VARIANTS[ev.status] || 'bg-slate-100 text-slate-700')}>
                      {ev.status?.replace('_', ' ')}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-600">{ev.city || '—'}</td>
                  <td className="px-4 py-3 text-slate-600">
                    {ev.start_date ? new Date(ev.start_date).toLocaleDateString() : '—'}
                    {ev.end_date ? ` – ${new Date(ev.end_date).toLocaleDateString()}` : ''}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : (
        <Card className="p-8 text-center text-slate-500">
          No events have been created yet.
        </Card>
      )}

      <Card className="bg-slate-50 p-4">
        <div className="flex items-center gap-3 text-sm text-slate-600">
          <span className="text-lg">ℹ️</span>
          <span>
            System Admin manages platform master data (Sports, Disciplines, Formats, Institutions, Roles). 
            Event management is delegated to Organiser accounts who can only access their own events.
          </span>
        </div>
      </Card>
    </div>
  );
}
