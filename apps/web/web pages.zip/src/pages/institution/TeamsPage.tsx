import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../lib/auth';
import { api } from '../../lib/api';
import { useApi, useApiMutation } from '../../lib/hooks';
import { Button, Card, Checkbox, EmptyState, Field, Input, Modal, PageHeader, Select, Spinner, StatusBadge } from '../../components/ui';

function drawLabel(d: any): string {
  const sport = d.tournament_sports?.sports?.name ?? 'Sport';
  const disc = d.disciplines?.name;
  return disc ? `${sport} · ${disc}` : sport;
}

// Enter one team for every selected discipline in a single action.
function BulkCreateTeamsModal({ approved, institution, onClose }:
  { approved: any[]; institution: any; onClose: () => void }) {
  const navigate = useNavigate();
  const [enrollmentId, setEnrollmentId] = useState(approved[0]?.id ?? '');
  const enrollment = approved.find((e) => e.id === enrollmentId);
  const eventId = enrollment?.event_id;
  const { data: draws = [], isLoading } = useApi<any[]>(eventId ? `/events/${eventId}/draws` : null);
  const { data: existing = [] } = useApi<any[]>(institution?.id ? `/teams?institution_id=${institution.id}` : null);

  // Don't offer draws this institution has already entered for this event.
  const takenDrawIds = useMemo(
    () => new Set(existing.filter((t) => t.event_id === eventId).map((t) => t.tournament_discipline_id).filter(Boolean)),
    [existing, eventId],
  );
  const available = useMemo(() => draws.filter((d) => !takenDrawIds.has(d.id)), [draws, takenDrawIds]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const short = institution?.short_name || institution?.name || 'Team';

  const create = useApiMutation<{ teams: any[] }, { created: number; teams: any[] }>(
    (body) => api('POST', '/teams/bulk', body),
    ['/me/teams', `/teams?institution_id=${institution?.id}`],
  );

  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const allChecked = available.length > 0 && selected.size === available.length;

  const submit = () => {
    setError(null);
    if (!enrollment || selected.size === 0) { setError('Select at least one discipline'); return; }
    const teams = available.filter((d) => selected.has(d.id)).map((d) => ({
      event_id: enrollment.event_id,
      institution_id: institution.id,
      event_institution_id: enrollment.id,
      sport_id: d.tournament_sports.sport_id,
      tournament_discipline_id: d.id,
      name: `${short} ${drawLabel(d).replace(' · ', ' ')}`,
    }));
    create.mutate({ teams }, {
      onSuccess: (r) => { if (r.teams?.[0]) navigate(`/inst/teams/${r.teams[0].id}`); else onClose(); },
      onError: (e: any) => setError(e.message),
    });
  };

  return (
    <Modal title="Enter multiple teams" onClose={onClose} wide>
      <Field label="Event">
        <Select value={enrollmentId} onChange={(e) => { setEnrollmentId(e.target.value); setSelected(new Set()); }}>
          {approved.map((e) => <option key={e.id} value={e.id}>{e.events?.name}</option>)}
        </Select>
      </Field>
      <div className="mb-2 text-sm font-semibold text-slate-600">Disciplines</div>
      {isLoading ? <Spinner /> : available.length === 0 ? (
        <p className="rounded-xl bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">
          {draws.length === 0 ? 'No disciplines configured for this event yet.' : 'You have already entered every available discipline.'}
        </p>
      ) : (
        <div className="max-h-72 overflow-auto rounded-xl border border-slate-200">
          <label className="flex items-center gap-3 border-b border-slate-100 bg-slate-50 px-4 py-2 text-sm font-semibold text-slate-600">
            <Checkbox checked={allChecked} indeterminate={selected.size > 0 && !allChecked}
              onChange={(v) => setSelected(v ? new Set(available.map((d) => d.id)) : new Set())} />
            Select all ({available.length})
          </label>
          {available.map((d) => (
            <label key={d.id} className="flex cursor-pointer items-center gap-3 border-b border-slate-100 px-4 py-2.5 last:border-0 hover:bg-slate-50">
              <Checkbox checked={selected.has(d.id)} onChange={() => toggle(d.id)} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium text-slate-800">{drawLabel(d)}</div>
                <div className="truncate text-xs text-slate-400">{d.entry_type} · squad {d.squad_min ?? d.disciplines?.squad_min ?? 1}–{d.squad_max ?? d.disciplines?.squad_max ?? 15} · {short} {drawLabel(d).replace(' · ', ' ')}</div>
              </div>
            </label>
          ))}
        </div>
      )}
      {error && <p className="mt-3 text-sm text-rose-600">{error}</p>}
      <div className="mt-5 flex items-center justify-between">
        <span className="text-sm text-slate-500">{selected.size} selected</span>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={selected.size === 0 || create.isPending} onClick={submit}>{create.isPending ? 'Creating…' : `Create ${selected.size || ''} team${selected.size === 1 ? '' : 's'}`}</Button>
        </div>
      </div>
    </Modal>
  );
}

function CreateTeamModal({ approved, institutionId, onClose }: { approved: any[]; institutionId: string; onClose: () => void }) {
  const navigate = useNavigate();
  const [enrollmentId, setEnrollmentId] = useState(approved[0]?.id ?? '');
  const enrollment = approved.find((e) => e.id === enrollmentId);
  const eventId = enrollment?.event_id;

  const { data: tournaments = [] } = useApi<any[]>(eventId ? `/tournaments?event_id=${eventId}` : null);
  const [tournamentId, setTournamentId] = useState('');
  const activeTournament = tournamentId || tournaments[0]?.id || '';
  const { data: tsports = [] } = useApi<any[]>(activeTournament ? `/tournament-sports?tournament_id=${activeTournament}` : null);
  const { data: sports = [] } = useApi<any[]>('/sports');
  const [tsId, setTsId] = useState('');
  const ts = tsports.find((t) => t.id === tsId) ?? tsports[0];
  const { data: draws = [] } = useApi<any[]>(ts ? `/tournament-disciplines?tournament_sport_id=${ts.id}` : null);
  const [drawId, setDrawId] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const create = useApiMutation(
    (body: any) => api('POST', '/teams', body),
    ['/me/teams', `/teams?institution_id=${institutionId}`],
    (team: any) => navigate(`/inst/teams/${team.id}`),
  );

  const sportName = (id: string) => sports.find((s) => s.id === id)?.name ?? 'Sport';

  const submit = () => {
    setError(null);
    if (!enrollment || !ts) { setError('Select an event and sport'); return; }
    create.mutate({
      event_id: enrollment.event_id,
      institution_id: institutionId,
      event_institution_id: enrollment.id,
      sport_id: ts.sport_id,
      tournament_discipline_id: drawId || (draws[0]?.id ?? null),
      name,
    }, { onError: (e: any) => setError(e.message) });
  };

  return (
    <Modal title="Enter a team" onClose={onClose}>
      <Field label="Event">
        <Select value={enrollmentId} onChange={(e) => { setEnrollmentId(e.target.value); setTournamentId(''); setTsId(''); setDrawId(''); }}>
          {approved.map((e) => <option key={e.id} value={e.id}>{e.events?.name}</option>)}
        </Select>
      </Field>
      {tournaments.length > 1 && (
        <Field label="Tournament">
          <Select value={activeTournament} onChange={(e) => { setTournamentId(e.target.value); setTsId(''); }}>
            {tournaments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </Select>
        </Field>
      )}
      <Field label="Sport">
        <Select value={ts?.id ?? ''} onChange={(e) => { setTsId(e.target.value); setDrawId(''); }}>
          {tsports.length === 0 && <option value="">No sports configured</option>}
          {tsports.map((t) => <option key={t.id} value={t.id}>{sportName(t.sport_id)}</option>)}
        </Select>
      </Field>
      {draws.length > 0 && (
        <Field label="Discipline / draw">
          <Select value={drawId || draws[0]?.id} onChange={(e) => setDrawId(e.target.value)}>
            {draws.map((d) => <option key={d.id} value={d.id}>{d.disciplines?.name ?? sportName(ts!.sport_id)} ({d.entry_type})</option>)}
          </Select>
        </Field>
      )}
      <Field label="Team name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. VJTI Titans" /></Field>
      {error && <p className="mb-2 text-sm text-rose-600">{error}</p>}
      <div className="flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button disabled={!name || create.isPending} onClick={submit}>{create.isPending ? 'Creating…' : 'Create team'}</Button>
      </div>
    </Modal>
  );
}

export function TeamsPage() {
  const { ctx } = useAuth();
  const navigate = useNavigate();
  const institutionId = ctx?.institution?.id ?? ctx?.user.institution_id ?? '';
  const { data: teams = [], isLoading } = useApi<any[]>(institutionId ? `/teams?institution_id=${institutionId}` : null);
  const { data: enrollments = [] } = useApi<any[]>('/me/enrollments');
  const approved = enrollments.filter((e) => e.status === 'approved');
  const [creating, setCreating] = useState(false);
  const [bulkCreating, setBulkCreating] = useState(false);

  return (
    <div>
      <PageHeader title="Teams" subtitle="Enter and manage teams across your approved events.">
        <Button variant="outline" onClick={() => setBulkCreating(true)} disabled={approved.length === 0}>+ Enter multiple</Button>
        <Button onClick={() => setCreating(true)} disabled={approved.length === 0}>+ Enter a team</Button>
      </PageHeader>

      {approved.length === 0 && (
        <p className="mb-4 rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-700">You need an approved event registration before entering teams. Apply via “Browse events”.</p>
      )}

      {isLoading ? <Spinner /> : teams.length === 0 ? (
        <EmptyState icon="⚇" title="No teams yet" description="Enter a team for one of your approved events."
          action={approved.length > 0 ? <Button onClick={() => setCreating(true)}>+ Enter a team</Button> : undefined} />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((t) => (
            <Card key={t.id} className="cursor-pointer p-4 transition hover:border-brand-300 hover:shadow-md" onClick={() => navigate(`/inst/teams/${t.id}`)}>
              <div className="flex items-start justify-between">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-50 text-lg">{t.sports?.icon ?? '◇'}</span>
                <StatusBadge status={t.status} />
              </div>
              <h3 className="mt-3 font-semibold text-slate-900">{t.name}</h3>
              <p className="text-sm text-slate-500">{t.sports?.name} · {t.events?.name}</p>
              <p className="mt-2 text-xs text-slate-400">{t.team_members?.length ?? 0} member{(t.team_members?.length ?? 0) === 1 ? '' : 's'}</p>
            </Card>
          ))}
        </div>
      )}

      {creating && institutionId && <CreateTeamModal approved={approved} institutionId={institutionId} onClose={() => setCreating(false)} />}
      {bulkCreating && institutionId && <BulkCreateTeamsModal approved={approved} institution={ctx?.institution ?? { id: institutionId }} onClose={() => setBulkCreating(false)} />}
    </div>
  );
}
