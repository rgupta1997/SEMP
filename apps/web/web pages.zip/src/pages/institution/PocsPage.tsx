import { useAuth } from '../../lib/auth';
import { useApi } from '../../lib/hooks';
import { Avatar, Badge, Card, CardBody, EmptyState, PageHeader, Spinner } from '../../components/ui';

export function PocsPage() {
  const { ctx } = useAuth();
  const institutionId = ctx?.institution?.id ?? ctx?.user.institution_id ?? '';
  const { data: users = [], isLoading } = useApi<any[]>('/users');
  const people = users.filter((u) => u.institution_id === institutionId);

  return (
    <div>
      <PageHeader title="Points of contact" subtitle="Staff and captains linked to your institution." />
      {isLoading ? <Spinner /> : people.length === 0 ? (
        <EmptyState icon="⚿" title="No contacts yet" description="Users linked to your institution will appear here." />
      ) : (
        <Card>
          <CardBody className="divide-y divide-slate-100 p-0">
            {people.map((u) => (
              <div key={u.id} className="flex items-center justify-between px-5 py-3">
                <div className="flex items-center gap-3">
                  <Avatar name={u.name} size={38} />
                  <div>
                    <div className="text-sm font-semibold text-slate-800">{u.name}</div>
                    <div className="text-xs text-slate-500">{u.email}{u.phone ? ` · ${u.phone}` : ''}</div>
                  </div>
                </div>
                <Badge tone={u.account_type === 'institution' ? 'brand' : 'slate'}>{u.account_type}</Badge>
              </div>
            ))}
          </CardBody>
        </Card>
      )}
      <p className="mt-4 text-xs text-slate-400">New institution staff can self-serve sign up and select your institution, or be invited by an organiser.</p>
    </div>
  );
}
