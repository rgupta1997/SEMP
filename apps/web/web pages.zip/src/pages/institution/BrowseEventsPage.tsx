import { useAuth } from '../../lib/auth';
import { api } from '../../lib/api';
import { useApi, useApiMutation, fmtDateRange } from '../../lib/hooks';
import { Badge, Button, Card, EmptyState, PageHeader, Spinner, StatusBadge } from '../../components/ui';

export function BrowseEventsPage() {
  const { ctx } = useAuth();
  const institutionId = ctx?.institution?.id ?? ctx?.user.institution_id ?? null;
  const { data: events = [], isLoading } = useApi<any[]>('/events');
  const { data: enrollments = [] } = useApi<any[]>('/me/enrollments');

  const apply = useApiMutation(
    (eventId: string) => api('POST', `/events/${eventId}/enroll`, { institution_id: institutionId }),
    ['/me/enrollments'],
  );

  const statusFor = (eventId: string) => enrollments.find((e) => e.event_id === eventId)?.status as string | undefined;
  const open = events.filter((e) => e.status === 'registration_open' || statusFor(e.id));

  if (!institutionId) {
    return <EmptyState icon="🏛" title="No institution linked" description="Your account must be linked to an institution before you can apply to events." />;
  }

  return (
    <div>
      <PageHeader title="Browse events" subtitle="Apply to participate — once approved you can enter teams." />
      {isLoading ? <Spinner /> : open.length === 0 ? (
        <EmptyState icon="◆" title="No open events" description="There are no events open for registration right now." />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {open.map((e) => {
            const status = statusFor(e.id);
            return (
              <Card key={e.id} className="flex flex-col p-5">
                <div className="flex items-start justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-50 text-lg font-black text-brand-600">{e.name.slice(0, 1)}</span>
                  <StatusBadge status={e.status} />
                </div>
                <h3 className="mt-3 font-semibold text-slate-900">{e.name}</h3>
                <p className="text-sm text-slate-500">{e.venue || 'Venue TBD'} · {fmtDateRange(e.start_date, e.end_date)}</p>
                <div className="mt-4 flex-1" />
                {status ? (
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Your application</span>
                    <StatusBadge status={status} />
                  </div>
                ) : e.status === 'registration_open' ? (
                  <Button className="w-full" disabled={apply.isPending}
                    onClick={() => apply.mutate(e.id, { onError: (err: any) => alert(err.message) })}>
                    {apply.isPending ? 'Applying…' : 'Apply to participate'}
                  </Button>
                ) : (
                  <Badge tone="slate">Registration closed</Badge>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
