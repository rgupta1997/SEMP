import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api } from '../../lib/api';
import { useApi, useApiMutation } from '../../lib/hooks';
import { Avatar, Badge, Button, Card, CardBody, CardHeader, Checkbox, Modal, Spinner, StatusBadge, Tabs, Textarea } from '../../components/ui';

interface BulkResult { added: number; skipped: { label: string; reason: string }[]; total: number }

// Parse pasted roster lines: "Name, email@x.com, 7" (jersey optional, order-tolerant
// for email vs name). One member per non-empty line.
function parsePasted(text: string): { name?: string; email?: string; jersey_number?: number }[] {
  return text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((line) => {
    const parts = line.split(/[,\t;]/).map((p) => p.trim()).filter(Boolean);
    const email = parts.find((p) => /\S+@\S+\.\S+/.test(p));
    const jerseyTok = parts.find((p) => /^#?\d{1,3}$/.test(p));
    const name = parts.find((p) => p !== email && p !== jerseyTok);
    return {
      name,
      email,
      jersey_number: jerseyTok ? Number(jerseyTok.replace('#', '')) : undefined,
    };
  }).filter((m) => m.email || m.name);
}

function BulkAddMembersModal({ teamId, institutionId, existingUserIds, remaining, onClose }:
  { teamId: string; institutionId?: string; existingUserIds: Set<string>; remaining: number; onClose: () => void }) {
  const [tab, setTab] = useState('roster');
  const { data: users = [], isLoading } = useApi<any[]>(institutionId ? `/users?institution_id=${institutionId}` : '/users');
  const candidates = useMemo(() => users.filter((u) => !existingUserIds.has(u.id)), [users, existingUserIds]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [paste, setPaste] = useState('');
  const [role, setRole] = useState('player');
  const [result, setResult] = useState<BulkResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const parsed = useMemo(() => parsePasted(paste), [paste]);
  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const allChecked = candidates.length > 0 && selected.size === candidates.length;

  const bulk = useApiMutation<{ members: any[] }, BulkResult>(
    (body) => api('POST', `/teams/${teamId}/members/bulk`, body),
    [`/teams/${teamId}`],
  );

  const members = tab === 'roster'
    ? candidates.filter((u) => selected.has(u.id)).map((u) => ({ user_id: u.id, role }))
    : parsed.map((m) => ({ ...m, role }));

  const submit = () => {
    setError(null);
    if (members.length === 0) { setError('Nothing to add'); return; }
    bulk.mutate({ members }, {
      onSuccess: (r) => setResult(r),
      onError: (e: any) => setError(e.message),
    });
  };

  if (result) {
    return (
      <Modal title="Import complete" onClose={onClose}>
        <p className="mb-3 text-sm text-slate-600"><span className="font-bold text-emerald-600">{result.added}</span> player{result.added === 1 ? '' : 's'} added · squad now {result.total}.</p>
        {result.skipped.length > 0 && (
          <div className="mb-3 max-h-48 overflow-auto rounded-xl bg-slate-50 p-3 text-sm">
            <div className="mb-1 font-semibold text-slate-600">Skipped {result.skipped.length}:</div>
            {result.skipped.map((s, i) => <div key={i} className="text-slate-500">{s.label} — {s.reason}</div>)}
          </div>
        )}
        <div className="flex justify-end"><Button onClick={onClose}>Done</Button></div>
      </Modal>
    );
  }

  return (
    <Modal title="Add players" onClose={onClose} wide>
      <div className="mb-4">
        <Tabs active={tab} onChange={setTab} tabs={[
          { id: 'roster', label: 'From institution', badge: candidates.length || undefined },
          { id: 'paste', label: 'Paste list' },
        ]} />
      </div>

      <div className="mb-3 flex items-center justify-between text-sm">
        <span className="text-slate-500">{remaining} squad slot{remaining === 1 ? '' : 's'} left</span>
        <label className="flex items-center gap-2">
          <span className="text-slate-500">Add as</span>
          <select value={role} onChange={(e) => setRole(e.target.value)} className="rounded-lg border border-slate-300 px-2 py-1 text-sm">
            <option value="player">player</option>
            <option value="captain">captain</option>
            <option value="manager">manager</option>
            <option value="coach">coach</option>
          </select>
        </label>
      </div>

      {tab === 'roster' ? (
        isLoading ? <Spinner /> : candidates.length === 0 ? (
          <p className="rounded-xl bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">Everyone from this institution is already on the roster. Use “Paste list” to add new people.</p>
        ) : (
          <div className="max-h-72 overflow-auto rounded-xl border border-slate-200">
            <label className="flex items-center gap-3 border-b border-slate-100 bg-slate-50 px-4 py-2 text-sm font-semibold text-slate-600">
              <Checkbox checked={allChecked} indeterminate={selected.size > 0 && !allChecked}
                onChange={(v) => setSelected(v ? new Set(candidates.map((u) => u.id)) : new Set())} />
              Select all ({candidates.length})
            </label>
            {candidates.map((u) => (
              <label key={u.id} className="flex cursor-pointer items-center gap-3 border-b border-slate-100 px-4 py-2.5 last:border-0 hover:bg-slate-50">
                <Checkbox checked={selected.has(u.id)} onChange={() => toggle(u.id)} />
                <Avatar name={u.name} size={32} />
                <div className="min-w-0"><div className="truncate text-sm font-medium text-slate-800">{u.name}</div><div className="truncate text-xs text-slate-500">{u.email}</div></div>
              </label>
            ))}
          </div>
        )
      ) : (
        <div>
          <Textarea rows={7} value={paste} onChange={(e) => setPaste(e.target.value)}
            placeholder={"One per line:\nAarav Mehta, aarav@vjti.local, 7\nRohan Kulkarni, rohan@vjti.local\nkiran@vjti.local"} />
          <p className="mt-1.5 text-xs text-slate-400">Format: <span className="font-medium">Name, email, jersey#</span> — email is required, name & jersey optional. New people are created under your institution. {parsed.length > 0 && <span className="text-brand-600">{parsed.length} row{parsed.length === 1 ? '' : 's'} detected.</span>}</p>
        </div>
      )}

      {error && <p className="mt-3 text-sm text-rose-600">{error}</p>}
      <div className="mt-5 flex items-center justify-between">
        <span className="text-sm text-slate-500">{members.length} selected</span>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button disabled={members.length === 0 || bulk.isPending} onClick={submit}>{bulk.isPending ? 'Adding…' : `Add ${members.length || ''} player${members.length === 1 ? '' : 's'}`}</Button>
        </div>
      </div>
    </Modal>
  );
}

export function RosterPage() {
  const { teamId } = useParams();
  const navigate = useNavigate();
  const path = `/teams/${teamId}`;
  const { data: team, isLoading } = useApi<any>(path);
  const [adding, setAdding] = useState(false);
  const [copied, setCopied] = useState(false);

  const lock = useApiMutation(() => api('POST', `/teams/${teamId}/lock`, {}), [path]);
  const removeMember = useApiMutation((memberId: string) => api('DELETE', `/teams/${teamId}/members/${memberId}`), [path]);

  if (isLoading || !team) return <Spinner />;
  const members = team.team_members ?? [];
  const locked = team.status === 'roster_locked';
  const inviteUrl = team.invite_token ? `${window.location.origin}/join/${team.invite_token}` : '';
  const rules = team.entry_rules ?? { entry_type: 'team', squad_min: 1, squad_max: 15 };
  const activeCount = members.filter((m: any) => m.is_active !== false).length;
  const belowMin = activeCount < rules.squad_min;
  const atMax = activeCount >= rules.squad_max;
  const existingUserIds = new Set<string>(members.map((m: any) => m.user_id).filter(Boolean));
  const remaining = Math.max(0, rules.squad_max - activeCount);

  return (
    <div>
      <button onClick={() => navigate('/inst/teams')} className="mb-3 text-sm font-medium text-slate-500 hover:text-slate-800">← All teams</button>
      <div className="mb-5 flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-2xl">{team.sports?.icon ?? '◇'}</span>
          <div>
            <div className="flex items-center gap-2"><h1 className="text-2xl font-bold text-slate-900">{team.name}</h1><StatusBadge status={team.status} /></div>
            <p className="text-sm text-slate-500">
              {team.sports?.name}
              {team.tournament_disciplines?.disciplines?.name ? ` · ${team.tournament_disciplines.disciplines.name}` : ''}
              {' · '}{team.institutions?.name}
            </p>
            <p className="text-xs text-slate-400">{rules.entry_type} entry · squad {rules.squad_min}–{rules.squad_max} players</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {inviteUrl && (
            <Button variant="outline" onClick={() => { navigator.clipboard?.writeText(inviteUrl); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>
              {copied ? 'Copied ✓' : 'Copy invite link'}
            </Button>
          )}
          {!locked && <Button onClick={() => lock.mutate(undefined, { onError: (e: any) => alert(e.message) })} disabled={lock.isPending || belowMin} title={belowMin ? `Need at least ${rules.squad_min} players` : undefined}>Lock roster</Button>}
        </div>
      </div>

      <Card>
        <CardHeader title={`Squad · ${activeCount}/${rules.squad_max}`}
          subtitle={locked ? 'Roster is locked' : belowMin ? `Add at least ${rules.squad_min - activeCount} more to lock` : 'Add players directly or share the invite link'}
          action={!locked && <Button size="sm" variant="subtle" disabled={atMax} title={atMax ? 'Squad is full' : undefined} onClick={() => setAdding(true)}>+ Add players</Button>} />
        <CardBody>
          {members.length === 0 ? (
            <p className="rounded-xl bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">No players yet. Add members or share the invite link.</p>
          ) : (
            <div className="space-y-2">
              {members.map((m: any) => (
                <div key={m.id} className="flex items-center justify-between rounded-xl border border-slate-200 px-4 py-2.5">
                  <div className="flex items-center gap-3">
                    <Avatar name={m.users?.name} size={36} />
                    <div>
                      <div className="text-sm font-semibold text-slate-800">{m.users?.name}{m.jersey_number != null && <span className="ml-2 text-slate-400">#{m.jersey_number}</span>}</div>
                      <div className="text-xs text-slate-500">{m.users?.email}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={m.role === 'captain' ? 'brand' : 'slate'}>{m.role.replace(/_/g, ' ')}</Badge>
                    {!locked && <button onClick={() => { if (confirm('Remove member?')) removeMember.mutate(m.id); }} className="text-sm text-rose-500 hover:underline">Remove</button>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>

      {adding && <BulkAddMembersModal teamId={teamId!} institutionId={team.institutions?.id ?? team.institution_id} existingUserIds={existingUserIds} remaining={remaining} onClose={() => setAdding(false)} />}
    </div>
  );
}
