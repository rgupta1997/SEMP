import { Link } from 'react-router-dom';
import { useAuth } from '../../lib/auth';
import { useApi } from '../../lib/hooks';
import { Avatar, Badge, Card, CardBody, CardHeader, EmptyState, PageHeader, Spinner, StatCard } from '../../components/ui';

export function StudentsPage() {
  const { ctx } = useAuth();
  const institutionId = ctx?.institution?.id ?? ctx?.user.institution_id ?? '';
  const { data: teams = [], isLoading } = useApi<any[]>(institutionId ? `/teams?institution_id=${institutionId}` : null);

  const uniquePlayers = new Set<string>();
  teams.forEach((t) => (t.team_members ?? []).forEach((m: any) => uniquePlayers.add(m.user_id)));

  return (
    <div>
      <PageHeader title="Students" subtitle="Everyone representing your institution, grouped by team." />
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Teams" value={teams.length} />
        <StatCard label="Unique students" value={uniquePlayers.size} />
        <StatCard label="Sports" value={new Set(teams.map((t) => t.sport_id)).size} />
      </div>
      {isLoading ? <Spinner /> : teams.length === 0 ? (
        <EmptyState icon="👥" title="No squads yet" description="Enter teams and add players to see your contingent here." />
      ) : (
        <div className="space-y-4">
          {teams.map((t) => {
            const members = t.team_members ?? [];
            return (
              <Card key={t.id}>
                <CardHeader
                  title={<Link to={`/inst/teams/${t.id}`} className="hover:text-brand-600">{t.name}</Link>}
                  subtitle={`${t.sports?.name ?? ''} · ${t.events?.name ?? ''}`}
                  action={<Badge tone="slate">{members.length} player{members.length === 1 ? '' : 's'}</Badge>}
                />
                <CardBody>
                  {members.length === 0 ? (
                    <p className="text-sm text-slate-400">No players yet.</p>
                  ) : (
                    <div className="grid gap-2 sm:grid-cols-2">
                      {members.map((m: any) => (
                        <div key={m.id} className="flex items-center gap-3 rounded-xl bg-slate-50 px-3 py-2">
                          <Avatar name={m.users?.name} size={32} />
                          <div className="min-w-0">
                            <div className="truncate text-sm font-medium text-slate-800">{m.users?.name}{m.jersey_number != null && <span className="ml-1.5 text-slate-400">#{m.jersey_number}</span>}</div>
                            <div className="truncate text-xs text-slate-500">{m.role.replace(/_/g, ' ')}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardBody>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
