import type {
  ButtonHTMLAttributes, HTMLAttributes, InputHTMLAttributes, ReactNode,
  SelectHTMLAttributes, TextareaHTMLAttributes,
} from 'react';

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/* ----------------------------- Button ----------------------------- */
type ButtonVariant = 'primary' | 'ghost' | 'outline' | 'danger' | 'subtle';
type ButtonSize = 'sm' | 'md' | 'lg';

export function Button({
  className = '', variant = 'primary', size = 'md', ...p
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; size?: ButtonSize }) {
  const variants: Record<ButtonVariant, string> = {
    primary: 'bg-brand-500 text-white hover:bg-brand-600 shadow-sm',
    ghost: 'text-slate-600 hover:bg-slate-100',
    outline: 'border border-slate-300 text-slate-700 bg-white hover:bg-slate-50',
    danger: 'bg-rose-600 text-white hover:bg-rose-700 shadow-sm',
    subtle: 'bg-brand-50 text-brand-700 hover:bg-brand-100',
  };
  const sizes: Record<ButtonSize, string> = {
    sm: 'px-2.5 py-1.5 text-xs rounded-lg gap-1.5',
    md: 'px-3.5 py-2 text-sm rounded-lg gap-2',
    lg: 'px-5 py-2.5 text-base rounded-xl gap-2',
  };
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap',
        variants[variant], sizes[size], className,
      )}
      {...p}
    />
  );
}

/* ----------------------------- Inputs ----------------------------- */
const fieldBase =
  'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-brand-400 disabled:bg-slate-100';

export const Input = ({ className = '', ...p }: InputHTMLAttributes<HTMLInputElement>) =>
  <input className={cn(fieldBase, className)} {...p} />;

export const Select = ({ className = '', ...p }: SelectHTMLAttributes<HTMLSelectElement>) =>
  <select className={cn(fieldBase, 'pr-8', className)} {...p} />;

export const Textarea = ({ className = '', ...p }: TextareaHTMLAttributes<HTMLTextAreaElement>) =>
  <textarea className={cn(fieldBase, className)} {...p} />;

export const Field = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
  <label className="block mb-4">
    <span className="block text-xs font-semibold text-slate-600 mb-1.5">{label}</span>
    {children}
    {hint && <span className="block text-xs text-slate-400 mt-1">{hint}</span>}
  </label>
);

/* ----------------------------- Card ----------------------------- */
export function Card({ className = '', children, ...p }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn('rounded-2xl border border-slate-200 bg-white shadow-sm', className)} {...p}>
      {children}
    </div>
  );
}

export function CardHeader({ title, subtitle, action }: { title: ReactNode; subtitle?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 px-5 pt-5 pb-3">
      <div>
        <h3 className="font-semibold text-slate-900">{title}</h3>
        {subtitle && <p className="text-sm text-slate-500 mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export const CardBody = ({ className = '', children }: { className?: string; children: ReactNode }) =>
  <div className={cn('px-5 pb-5', className)}>{children}</div>;

/* ----------------------------- Badge ----------------------------- */
type BadgeTone = 'brand' | 'green' | 'amber' | 'rose' | 'slate' | 'violet';
export function Badge({ tone = 'slate', className = '', children }: { tone?: BadgeTone; className?: string; children: ReactNode }) {
  const tones: Record<BadgeTone, string> = {
    brand: 'bg-brand-50 text-brand-700 ring-brand-200',
    green: 'bg-emerald-50 text-emerald-700 ring-emerald-200',
    amber: 'bg-amber-50 text-amber-700 ring-amber-200',
    rose: 'bg-rose-50 text-rose-700 ring-rose-200',
    slate: 'bg-slate-100 text-slate-600 ring-slate-200',
    violet: 'bg-violet-50 text-violet-700 ring-violet-200',
  };
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset', tones[tone], className)}>
      {children}
    </span>
  );
}

// Maps a status string to a sensible badge tone.
export function StatusBadge({ status }: { status?: string | null }) {
  const s = (status ?? '').toLowerCase();
  const tone: BadgeTone =
    ['approved', 'completed', 'active', 'ongoing', 'roster_locked', 'live'].includes(s) ? 'green'
    : ['pending', 'forming', 'upcoming', 'submitted', 'scheduled', 'draft'].includes(s) ? 'amber'
    : ['rejected', 'cancelled'].includes(s) ? 'rose'
    : ['registration_open'].includes(s) ? 'brand'
    : 'slate';
  return <Badge tone={tone}>{(status ?? '—').replace(/_/g, ' ')}</Badge>;
}

/* ----------------------------- Modal ----------------------------- */
export function Modal({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-auto bg-slate-900/50 p-4 sm:p-6 backdrop-blur-sm" onClick={onClose}>
      <div className={cn('mt-10 w-full rounded-2xl bg-white shadow-2xl', wide ? 'max-w-2xl' : 'max-w-lg')} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-2xl leading-none text-slate-400 hover:text-slate-700">×</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

/* ----------------------------- PageHeader ----------------------------- */
export function PageHeader({ title, subtitle, children }: { title: ReactNode; subtitle?: ReactNode; children?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

/* ----------------------------- StatCard ----------------------------- */
export function StatCard({ label, value, hint, accent }: { label: string; value: ReactNode; hint?: ReactNode; accent?: boolean }) {
  return (
    <div className={cn('rounded-2xl border p-4', accent ? 'border-brand-200 bg-brand-50' : 'border-slate-200 bg-white')}>
      <div className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</div>
      <div className={cn('mt-1 text-3xl font-bold', accent ? 'text-brand-600' : 'text-slate-900')}>{value}</div>
      {hint && <div className="mt-0.5 text-xs text-slate-500">{hint}</div>}
    </div>
  );
}

/* ----------------------------- Avatar ----------------------------- */
export function Avatar({ name, size = 36 }: { name?: string | null; size?: number }) {
  const initials = (name ?? '?')
    .split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join('') || '?';
  return (
    <span
      className="inline-grid flex-none place-items-center rounded-full bg-brand-100 font-semibold text-brand-700"
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {initials}
    </span>
  );
}

/* ----------------------------- Tabs ----------------------------- */
export function Tabs({ tabs, active, onChange }: { tabs: { id: string; label: ReactNode; badge?: ReactNode }[]; active: string; onChange: (id: string) => void }) {
  return (
    <div className="flex gap-1 border-b border-slate-200">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            '-mb-px flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors',
            active === t.id ? 'border-brand-500 text-brand-600' : 'border-transparent text-slate-500 hover:text-slate-800',
          )}
        >
          {t.label}{t.badge}
        </button>
      ))}
    </div>
  );
}

/* ----------------------------- Stepper ----------------------------- */
export function Stepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <ol className="flex flex-col gap-4">
      {steps.map((s, i) => {
        const done = i < current, active = i === current;
        return (
          <li key={s} className="flex items-center gap-3">
            <span className={cn(
              'grid h-7 w-7 flex-none place-items-center rounded-full border text-xs font-bold',
              done ? 'border-brand-500 bg-brand-500 text-white'
              : active ? 'border-brand-500 bg-brand-50 text-brand-600'
              : 'border-slate-300 text-slate-400',
            )}>{done ? '✓' : i + 1}</span>
            <span className={cn('text-sm font-semibold', active ? 'text-slate-900' : 'text-slate-500')}>{s}</span>
          </li>
        );
      })}
    </ol>
  );
}

/* ----------------------------- Toggle ----------------------------- */
export function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={cn('relative h-6 w-11 flex-none rounded-full transition-colors', checked ? 'bg-brand-500' : 'bg-slate-300')}
    >
      <span className={cn('absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all', checked ? 'left-[22px]' : 'left-0.5')} />
    </button>
  );
}

/* ----------------------------- EmptyState ----------------------------- */
export function EmptyState({ icon = '◎', title, description, action }: { icon?: ReactNode; title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-14 text-center">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-xl bg-slate-100 text-2xl text-slate-400">{icon}</div>
      <h3 className="font-semibold text-slate-800">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-slate-500">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ----------------------------- Spinner ----------------------------- */
export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-slate-500">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-slate-300 border-t-brand-500" />
      {label ?? 'Loading…'}
    </div>
  );
}

/* ----------------------------- Checkbox ----------------------------- */
export function Checkbox({ checked, indeterminate, onChange }: { checked: boolean; indeterminate?: boolean; onChange: (v: boolean) => void }) {
  return (
    <input
      type="checkbox"
      checked={checked}
      ref={(el) => { if (el) el.indeterminate = !!indeterminate && !checked; }}
      onChange={(e) => onChange(e.target.checked)}
      onClick={(e) => e.stopPropagation()}
      className="h-4 w-4 cursor-pointer rounded border-slate-300 text-brand-500 focus:ring-brand-400"
    />
  );
}

/* ----------------------------- BulkBar ----------------------------- */
// Sticky action bar shown when one or more rows are selected.
export function BulkBar({ count, children, onClear }: { count: number; children: ReactNode; onClear: () => void }) {
  if (count === 0) return null;
  return (
    <div className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand-200 bg-brand-50 px-4 py-2.5">
      <span className="text-sm font-semibold text-brand-700">{count} selected</span>
      <div className="flex items-center gap-2">
        {children}
        <button onClick={onClear} className="text-sm font-medium text-slate-500 hover:text-slate-800">Clear</button>
      </div>
    </div>
  );
}

/* ----------------------------- Table ----------------------------- */
export function Table({ children }: { children: ReactNode }) {
  return (
    <div className="overflow-auto rounded-2xl border border-slate-200 bg-white">
      <table className="w-full text-sm">{children}</table>
    </div>
  );
}
export const THead = ({ children }: { children: ReactNode }) =>
  <thead className="bg-slate-50 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">{children}</thead>;
export const TH = ({ children, className = '' }: { children?: ReactNode; className?: string }) =>
  <th className={cn('px-4 py-3 font-semibold', className)}>{children}</th>;
export const TR = ({ children, className = '', onClick }: { children: ReactNode; className?: string; onClick?: () => void }) =>
  <tr className={cn('border-t border-slate-100', onClick && 'cursor-pointer hover:bg-slate-50', className)} onClick={onClick}>{children}</tr>;
export const TD = ({ children, className = '' }: { children?: ReactNode; className?: string }) =>
  <td className={cn('px-4 py-3 align-middle', className)}>{children}</td>;
