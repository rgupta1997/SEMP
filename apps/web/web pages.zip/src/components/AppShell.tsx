import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { ROLE_LABELS, useAuth, type AppRole } from '../lib/auth';
import { Avatar, cn } from './ui';

interface NavItem { to: string; label: string; icon: string; end?: boolean }
interface NavGroup { group: string; items: NavItem[] }

export function roleHome(role: AppRole): string {
  switch (role) {
    case 'system': return '/platform/sports'; // System admin manages master data
    case 'organiser': return '/events';
    case 'institution': return '/inst';
    case 'official': return '/official';
    case 'participant': return '/me';
  }
}

function navFor(role: AppRole, isSuperAdmin: boolean): NavGroup[] {
  switch (role) {
    case 'system':
      // System Admin: only platform master data management
      return [{
        group: 'Platform Master Data', items: [
          { to: '/platform/sports', label: 'Sports', icon: '🏅' },
          { to: '/platform/disciplines', label: 'Disciplines', icon: '▦' },
          { to: '/platform/tournament-formats', label: 'Formats', icon: '⊟' },
          { to: '/platform/institutions', label: 'Institutions', icon: '🏛' },
          { to: '/platform/roles', label: 'Roles & Permissions', icon: '⚿' },
        ],
      }, {
        group: 'Platform Overview', items: [
          { to: '/platform/overview', label: 'All Events', icon: '◆' },
          { to: '/platform/users', label: 'All Users', icon: '◍' },
        ],
      }];
    case 'organiser': {
      // Organiser: only their events (multi-tenant isolated)
      return [
        { group: 'My Events', items: [{ to: '/events', label: 'Events', icon: '◆', end: false }] },
      ];
    }
    case 'institution':
      return [{ group: 'Institution', items: [
        { to: '/inst', label: 'Overview', icon: '◎', end: true },
        { to: '/inst/events', label: 'Browse events', icon: '◆' },
        { to: '/inst/teams', label: 'Teams', icon: '⚇' },
        { to: '/inst/students', label: 'Students', icon: '👥' },
        { to: '/inst/pocs', label: 'Points of contact', icon: '⚿' },
      ] }];
    case 'official':
      return [{ group: 'Match day', items: [
        { to: '/official', label: 'My matches', icon: '⚑', end: true },
      ] }];
    case 'participant':
      return [{ group: 'Me', items: [
        { to: '/me', label: 'Dashboard', icon: '◎', end: true },
        { to: '/me/matches', label: 'All matches', icon: '⚑' },
      ] }];
  }
}

function RoleSwitcher() {
  const { availableRoles, activeRole, setActiveRole } = useAuth();
  const navigate = useNavigate();
  if (availableRoles.length <= 1) return null;
  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="hidden text-xs font-semibold uppercase tracking-wide text-slate-400 sm:inline">View as</span>
      <select
        value={activeRole}
        onChange={(e) => {
          const r = e.target.value as AppRole;
          setActiveRole(r);
          navigate(roleHome(r));
        }}
        className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-sm font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-brand-400"
      >
        {availableRoles.map((r) => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}
      </select>
    </label>
  );
}

export function AppShell() {
  const { ctx, activeRole, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  if (!ctx) return null;
  const groups = navFor(activeRole, ctx.user.is_super_admin);
  const subtitle = activeRole === 'institution' && ctx.institution ? ctx.institution.name : ROLE_LABELS[activeRole];

  return (
    <div className="grid h-screen grid-cols-[260px_1fr]">
      {/* Sidebar */}
      <aside className="flex flex-col overflow-hidden border-r border-slate-800 bg-slate-900 text-slate-300">
        <div className="flex items-center gap-2.5 border-b border-slate-800 px-5 py-4">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500 text-lg font-black text-white">S</span>
          <div>
            <div className="text-lg font-bold leading-none text-white">Sportagon</div>
            <div className="mt-1 text-[10px] uppercase tracking-[0.16em] text-slate-500">SEMP Platform</div>
          </div>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          {groups.map((g) => (
            <div key={g.group} className="mb-5">
              <div className="px-2 pb-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-500">{g.group}</div>
              {g.items.map((it) => (
                <NavLink
                  key={it.to}
                  to={it.to}
                  end={it.end}
                  className={({ isActive }) => cn(
                    'mb-0.5 flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors',
                    isActive ? 'bg-brand-500 text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white',
                  )}
                >
                  <span className="w-5 text-center text-base">{it.icon}</span>
                  <span>{it.label}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="border-t border-slate-800 px-3 py-3 text-[11px] text-slate-500">
          Demo logins use password <span className="font-mono text-slate-400">demo123</span>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-w-0 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 py-3">
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold text-slate-800">{subtitle}</div>
          </div>
          <div className="flex items-center gap-4">
            <RoleSwitcher />
            <div className="relative">
              <button onClick={() => setMenuOpen((o) => !o)} className="flex items-center gap-2 rounded-lg px-1.5 py-1 hover:bg-slate-100">
                <Avatar name={ctx.user.name} size={32} />
                <span className="hidden text-sm font-medium text-slate-700 sm:inline">{ctx.user.name}</span>
              </button>
              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                  <div className="absolute right-0 z-20 mt-2 w-56 rounded-xl border border-slate-200 bg-white py-1 shadow-lg">
                    <div className="border-b border-slate-100 px-4 py-2">
                      <div className="text-sm font-semibold text-slate-800">{ctx.user.name}</div>
                      <div className="truncate text-xs text-slate-500">{ctx.user.email}</div>
                    </div>
                    <button onClick={logout} className="w-full px-4 py-2 text-left text-sm text-rose-600 hover:bg-rose-50">Sign out</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-auto bg-slate-100 p-6">
          <div className="mx-auto max-w-6xl">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
