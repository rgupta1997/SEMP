import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from './api';

// GET list/item with the path as the cache key.
export function useApi<T = any>(path: string | null, enabled = true) {
  return useQuery<T>({
    queryKey: [path],
    queryFn: () => api('GET', path as string),
    enabled: enabled && path !== null,
  });
}

// Mutation that invalidates the given query keys (paths) on success.
export function useApiMutation<TBody = any, TRes = any>(
  fn: (body: TBody) => Promise<TRes>,
  invalidate: (string | null)[] = [],
  onSuccess?: (res: TRes) => void,
) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: (res) => {
      invalidate.filter(Boolean).forEach((p) => qc.invalidateQueries({ queryKey: [p] }));
      onSuccess?.(res);
    },
  });
}

export function fmtDate(d?: string | Date | null): string {
  if (!d) return '—';
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

export function fmtDateTime(d?: string | Date | null): string {
  if (!d) return '—';
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export function fmtDateRange(a?: string | Date | null, b?: string | Date | null): string {
  if (!a || !b) return fmtDate(a) || fmtDate(b);
  return `${fmtDate(a)} – ${fmtDate(b)}`;
}
