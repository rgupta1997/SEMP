import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './lib/auth';
import { AppShell, roleHome } from './components/AppShell';
import { Spinner } from './components/ui';
import { AuthPage } from './pages/AuthPage';

import { EventsListPage } from './pages/organiser/EventsListPage';
import { CreateEventWizard } from './pages/organiser/CreateEventWizard';
import { EventLayout } from './pages/organiser/EventLayout';
import { EventDashboard } from './pages/organiser/EventDashboard';
import { EventSetupPage } from './pages/organiser/EventSetupPage';
import { ApprovalsPage } from './pages/organiser/ApprovalsPage';
import { SchedulePage } from './pages/organiser/SchedulePage';
import { StandingsPage } from './pages/organiser/StandingsPage';
import { EventSettingsPage } from './pages/organiser/EventSettingsPage';
import { EventParticipantsPage } from './pages/organiser/EventParticipantsPage';
import { EventOfficialsPage } from './pages/organiser/EventOfficialsPage';

import { InstitutionDashboard } from './pages/institution/InstitutionDashboard';
import { BrowseEventsPage } from './pages/institution/BrowseEventsPage';
import { TeamsPage } from './pages/institution/TeamsPage';
import { RosterPage } from './pages/institution/RosterPage';
import { StudentsPage } from './pages/institution/StudentsPage';
import { PocsPage } from './pages/institution/PocsPage';

import { OfficialFixturesPage } from './pages/official/OfficialFixturesPage';
import { MatchConsolePage } from './pages/official/MatchConsolePage';

import { ParticipantDashboard } from './pages/participant/ParticipantDashboard';
import { ParticipantEventPage } from './pages/participant/ParticipantEventPage';
import { ParticipantMatchesPage } from './pages/participant/ParticipantMatchesPage';
import { ParticipantMatchPage } from './pages/participant/ParticipantMatchPage';
import { PlatformResource } from './pages/platform/PlatformResource';
import { PlatformOverview } from './pages/platform/PlatformOverview';

function HomeRedirect() {
  const { activeRole } = useAuth();
  return <Navigate to={roleHome(activeRole)} replace />;
}

function AuthenticatedRoutes() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        {/* Organiser / System */}
        <Route path="/events" element={<EventsListPage />} />
        <Route path="/events/new" element={<CreateEventWizard />} />
        <Route path="/events/:eventId" element={<EventLayout />}>
          <Route index element={<EventDashboard />} />
          <Route path="setup" element={<EventSetupPage />} />
          <Route path="approvals" element={<ApprovalsPage />} />
          <Route path="participants" element={<EventParticipantsPage />} />
          <Route path="officials" element={<EventOfficialsPage />} />
          <Route path="schedule" element={<SchedulePage />} />
          <Route path="standings" element={<StandingsPage />} />
          <Route path="settings" element={<EventSettingsPage />} />
        </Route>
        <Route path="/platform/overview" element={<PlatformOverview />} />
        <Route path="/platform/:key" element={<PlatformResource />} />

        {/* Institution / Captain */}
        <Route path="/inst" element={<InstitutionDashboard />} />
        <Route path="/inst/events" element={<BrowseEventsPage />} />
        <Route path="/inst/teams" element={<TeamsPage />} />
        <Route path="/inst/teams/:teamId" element={<RosterPage />} />
        <Route path="/inst/students" element={<StudentsPage />} />
        <Route path="/inst/pocs" element={<PocsPage />} />

        {/* Official */}
        <Route path="/official" element={<OfficialFixturesPage />} />
        <Route path="/official/score/:fixtureId" element={<MatchConsolePage />} />

        {/* Participant */}
        <Route path="/me" element={<ParticipantDashboard />} />
        <Route path="/me/events/:eventId" element={<ParticipantEventPage />} />
        <Route path="/me/matches" element={<ParticipantMatchesPage />} />
        <Route path="/me/matches/:fixtureId" element={<ParticipantMatchPage />} />

        {/* Catch all - redirect to role home */}
        <Route path="*" element={<HomeRedirect />} />
      </Route>
    </Routes>
  );
}

function AppRoutes() {
  const { ctx, loading } = useAuth();
  
  if (loading) return <div className="grid h-screen place-items-center"><Spinner /></div>;
  
  return ctx ? <AuthenticatedRoutes /> : (
    <Routes>
      <Route path="*" element={<AuthPage />} />
    </Routes>
  );
}

export function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}
